<?php
session_start();
include 'config/database.php';

$message = "";

if(isset($_POST['register'])){

    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $contact = trim($_POST['contact']);
    $address = trim($_POST['address']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if passwords match
    if($password != $confirm_password){

        $message = "<div class='alert alert-danger'>Passwords do not match.</div>";

    }else{

        // Check if email already exists
        $check = $conn->prepare("SELECT user_id FROM users WHERE email=?");
        $check->bind_param("s",$email);
        $check->execute();
        $result = $check->get_result();

        if($result->num_rows > 0){

            $message = "<div class='alert alert-danger'>Email already exists.</div>";

        }else{

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users(first_name,last_name,email,contact,address,password) VALUES(?,?,?,?,?,?)");

            $stmt->bind_param(
                "ssssss",
                $first_name,
                $last_name,
                $email,
                $contact,
                $address,
                $hashedPassword
            );

            if($stmt->execute()){

                header("Location: login.php?registered=1");
                exit();

            }else{

                $message = "<div class='alert alert-danger'>Registration failed.</div>";

            }

        }

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Register | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#FFF8F0;
}

.register-section{
min-height:100vh;
display:flex;
align-items:center;
justify-content:center;
padding:40px;
}

.card{
border:none;
border-radius:20px;
overflow:hidden;
}

.card-header{
background:#6F4E37;
color:white;
text-align:center;
padding:25px;
}

.btn-register{
background:#D4AF37;
color:white;
font-weight:bold;
}

.btn-register:hover{
background:#b8922c;
color:white;
}

</style>

</head>

<body>

<section class="register-section">

<div class="container">

<div class="row justify-content-center">

<div class="col-lg-7">

<div class="card shadow">

<div class="card-header">

<h2>🍰 Graham Delight</h2>

<p>Create Your Account</p>

</div>

<div class="card-body p-4">

<?php echo $message; ?>

<form method="POST">

<div class="row">

<div class="col-md-6 mb-3">

<label>First Name</label>

<input type="text" name="first_name" class="form-control" required>

</div>

<div class="col-md-6 mb-3">

<label>Last Name</label>

<input type="text" name="last_name" class="form-control" required>

</div>

<div class="col-md-6 mb-3">

<label>Email</label>

<input type="email" name="email" class="form-control" required>

</div>

<div class="col-md-6 mb-3">

<label>Contact</label>

<input type="text" name="contact" class="form-control" required>

</div>

<div class="col-12 mb-3">

<label>Address</label>

<textarea name="address" class="form-control" rows="3"></textarea>

</div>

<div class="col-md-6 mb-3">

<label>Password</label>

<input type="password" name="password" class="form-control" required>

</div>

<div class="col-md-6 mb-3">

<label>Confirm Password</label>

<input type="password" name="confirm_password" class="form-control" required>

</div>

<div class="col-12">

<button class="btn btn-register w-100" name="register">

Create Account

</button>

</div>

</div>

</form>

<hr>

<div class="text-center">

Already have an account?

<a href="login.php">Login Here</a>

</div>

</div>

</div>

</div>

</div>

</div>

</section>

</body>

</html>