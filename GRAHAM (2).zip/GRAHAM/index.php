<?php
include 'config/database.php';

/* ==========================
   GET AVAILABLE PRODUCTS
========================== */

$sql = "
SELECT
    p.product_id,
    p.product_name,
    p.description,
    p.price,
    p.image,
    c.category_name,
    i.stock
FROM products p
LEFT JOIN categories c
    ON p.category_id = c.category_id
LEFT JOIN inventory i
    ON p.product_id = i.product_id
WHERE p.status = 'Available'
ORDER BY p.product_id DESC
";

$result = $conn->query($sql);

if (!$result) {
    die("Database Error: " . $conn->error);
}

/* Store products for the sections */
$products = [];

while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Graham Delight | Homemade Graham Desserts</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#FFF8F0;
}

.navbar{
    background:#6F4E37;
}

.hero{
    padding:90px 0;
}

.hero h1{
    font-size:55px;
    font-weight:700;
    color:#5C4033;
}

.hero p{
    font-size:18px;
}

.btn-order{
    background:#D4AF37;
    color:white;
    border:none;
    padding:12px 35px;
    border-radius:30px;
    font-weight:600;
}

.btn-order:hover{
    background:#b89328;
}

.card{
    transition:.3s;
    border:none;
}

.card:hover{
    transform:translateY(-10px);
}

.price{
    color:#D4AF37;
    font-size:25px;
    font-weight:bold;
}

.section-title{
    font-weight:700;
    color:#6F4E37;
}

footer{
    background:#6F4E37;
    color:white;
}

</style>

</head>

<body>

<!-- NAVBAR -->

<nav class="navbar navbar-expand-lg navbar-dark shadow">

<div class="container">

<a class="navbar-brand fw-bold" href="#">
🍍 Graham Delight
</a>

<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

    <li class="nav-item">
        <a class="nav-link active" href="index.php">Home</a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="customer/product.php">Products</a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
    </li>

</ul>

</div>

</div>

</nav>

<!-- HERO -->

<section class="hero">

<div class="container">

<div class="row align-items-center">

<div class="col-lg-6">

<h1>
Homemade Graham Desserts
</h1>

<p class="mt-4">

Experience our creamy and delicious homemade desserts made with premium ingredients. Every bite is crafted with love and freshness.

</p>

<a href="custoproduct.php" class="btn btn-order mt-3">
Shop Now
</a>

</div>

</div>

</div>

</div>

</section>

<!-- FEATURED CATEGORIES -->

<section class="py-5">

<div class="container">

<div class="text-center mb-5">

<h2 class="fw-bold" style="color:#6F4E37;">
Our Categories
</h2>

<p class="text-muted">
Choose your favorite homemade graham dessert.
</p>

</div>

<div class="row g-4">

<!-- Pineapplemisu -->

<div class="col-lg-3 col-md-6">

<div class="card border-0 shadow text-center h-100">

<img src="uploads/products/pineapplemisu.jpeg"
class="card-img-top"
style="height:250px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold">
Pineapplemisu
</h5>

<p class="text-muted">
A tropical twist on tiramisu with real pineapple chunks.
</p>

<a href="product.php?id=pineapplemisu"
class="btn btn-warning rounded-pill px-4">
View Product
</a>

</div>

</div>

</div>

<!-- Mango Graham -->

<div class="col-lg-3 col-md-6">

<div class="card border-0 shadow text-center h-100">

<img src="uploads/products/mangograham.jpeg"
class="card-img-top"
style="height:250px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold">
Mango Graham
</h5>

<p class="text-muted">
Fresh mangoes layered with rich cream and graham crackers.
</p>

<a href="product.php?id=mangograham"
class="btn btn-warning rounded-pill px-4">
View Product
</a>

</div>

</div>

</div>

<!-- Tiramisu Graham -->

<div class="col-lg-3 col-md-6">

<div class="card border-0 shadow text-center h-100">

<img src="uploads/products/tiramisu.jpeg"
class="card-img-top"
style="height:250px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold">
Tiramisu Graham
</h5>

<p class="text-muted">
Classic coffee-flavored graham dessert with creamy filling.
</p>

<a href="product.php?id=tiramisu"
class="btn btn-warning rounded-pill px-4">
View Product
</a>

</div>

</div>

</div>

<!-- Choco Graham -->

<div class="col-lg-3 col-md-6">

<div class="card border-0 shadow text-center h-100">

<img src="uploads/products/chocograham.png"
class="card-img-top"
style="height:250px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold">
Choco Graham
</h5>

<p class="text-muted">
Chocolate lovers' favorite with creamy chocolate layers.
</p>

<a href="product.php?id=chocograham"
class="btn btn-warning rounded-pill px-4">
View Product
</a>

</div>

</div>

</div>

</div>

</div>

</section>

<!-- BEST SELLERS -->

<section class="py-5 bg-light">

<div class="container">

<div class="text-center mb-5">

<h2 class="fw-bold" style="color:#6F4E37;">
🔥 Best Sellers
</h2>

<p class="text-muted">
Our customers' favorite desserts.
</p>

</div>

<div class="row">

<div class="col-lg-4">

<div class="card border-0 shadow-lg">

<img src="uploads/products/pineapplemisu.jpeg"
class="card-img-top">

<div class="card-body">

<h4>Pineapplemisu</h4>

<p>
⭐⭐⭐⭐⭐ (4.9)
</p>

<h5 class="text-warning">
₱149
</h5>

<button class="btn btn-dark w-100">
Add to Cart
</button>

</div>

</div>

</div>

<div class="col-lg-4">

<div class="card border-0 shadow-lg">

<img src="uploads/products/mangograham.jpeg"
class="card-img-top">

<div class="card-body">

<h4>Mango Graham</h4>

<p>
⭐⭐⭐⭐⭐ (4.8)
</p>

<h5 class="text-warning">
₱129
</h5>

<button class="btn btn-dark w-100">
Add to Cart
</button>

</div>

</div>

</div>

<div class="col-lg-4">

<div class="card border-0 shadow-lg">

<img src="uploads/products/tiramisu.jpeg"
class="card-img-top">

<div class="card-body">

<h4>Tiramisu Graham</h4>

<p>
⭐⭐⭐⭐⭐ (5.0)
</p>

<h5 class="text-warning">
₱159
</h5>

<button class="btn btn-dark w-100">
Add to Cart
</button>

</div>

</div>

</div>

</div>

</div>

</section>

<!-- ABOUT US -->

<section class="py-5" id="about">

<div class="container">

<div class="row align-items-center">

<div class="col-lg-6">

<img src="assets/images/hero.jpg"
class="img-fluid rounded-4 shadow">

</div>

<div class="col-lg-6">

<h2 class="fw-bold mb-4" style="color:#6F4E37;">
About Graham Delight
</h2>

<p class="text-muted">

At <strong>Graham Delight</strong>, we create delicious homemade graham desserts made from premium ingredients. Every dessert is freshly prepared with love to ensure every customer enjoys a rich, creamy, and satisfying experience.

</p>

<div class="row mt-4">

<div class="col-6 mb-3">

<div class="p-3 bg-light rounded text-center shadow-sm">

<h3>🍍</h3>

<h6 class="fw-bold">Fresh Ingredients</h6>

</div>

</div>

<div class="col-6 mb-3">

<div class="p-3 bg-light rounded text-center shadow-sm">

<h3>🥛</h3>

<h6 class="fw-bold">Creamy Recipe</h6>

</div>

</div>

<div class="col-6">

<div class="p-3 bg-light rounded text-center shadow-sm">

<h3>🚚</h3>

<h6 class="fw-bold">Fast Delivery</h6>

</div>

</div>

<div class="col-6">

<div class="p-3 bg-light rounded text-center shadow-sm">

<h3>❤️</h3>

<h6 class="fw-bold">Made with Love</h6>

</div>

</div>

</div>

<a href="customer/product.php"
class="btn btn-warning rounded-pill px-4 mt-4">

Explore Products

</a>

</div>

</div>

</div>

</section>

<!-- CUSTOMER REVIEWS -->

<section class="py-5 bg-light">

<div class="container">

<div class="text-center mb-5">

<h2 class="fw-bold" style="color:#6F4E37;">
What Our Customers Say
</h2>

<p class="text-muted">
Real feedback from our happy customers.
</p>

</div>

<div class="row">

<div class="col-lg-4">

<div class="card shadow border-0 h-100">

<div class="card-body text-center">

<img src="https://i.pravatar.cc/100?img=1"
class="rounded-circle mb-3">

<h5>Maria Santos</h5>

<p class="text-warning">
★★★★★
</p>

<p>

"The Pineapplemisu is incredibly delicious! I'll definitely order again."

</p>

</div>

</div>

</div>

<div class="col-lg-4">

<div class="card shadow border-0 h-100">

<div class="card-body text-center">

<img src="https://i.pravatar.cc/100?img=8"
class="rounded-circle mb-3">

<h5>John Cruz</h5>

<p class="text-warning">
★★★★★
</p>

<p>

"Best Mango Graham I've ever tasted. Super creamy and affordable."

</p>

</div>

</div>

</div>

<div class="col-lg-4">

<div class="card shadow border-0 h-100">

<div class="card-body text-center">

<img src="https://i.pravatar.cc/100?img=12"
class="rounded-circle mb-3">

<h5>Angela Reyes</h5>

<p class="text-warning">
★★★★★
</p>

<p>

"The Tiramisu Graham tastes premium. Highly recommended!"

</p>

</div>

</div>

</div>

</div>

</div>

</section>

<!-- CONTACT / CTA SECTION -->

<section class="py-5">

<div class="container">

<div class="row align-items-center">

<div class="col-lg-6">

<h2 class="fw-bold mb-4" style="color:#6F4E37;">
Ready to Satisfy Your Sweet Cravings?
</h2>

<p class="text-muted">

Order your favorite homemade graham dessert today! We prepare every dessert fresh to ensure the best quality and taste.

</p>

<div class="mt-4">

<p class="mb-2">
📍 Legazpi City, Albay
</p>

<p class="mb-2">
📞 +63 912 345 6789
</p>

<p class="mb-2">
📧 grahamdelight@email.com
</p>

<p class="mb-4">
🕘 Monday - Sunday | 9:00 AM - 8:00 PM
</p>

<a href="product.php" class="btn btn-warning btn-lg rounded-pill px-4">
Order Now
</a>

</div>

</div>

<div class="col-lg-6">

<div class="card shadow border-0">

<div class="card-body p-4">

<h4 class="mb-4 text-center">
Send us a Message
</h4>

<form>

<div class="mb-3">

<input
type="text"
class="form-control"
placeholder="Full Name">

</div>

<div class="mb-3">

<input
type="email"
class="form-control"
placeholder="Email Address">

</div>

<div class="mb-3">

<textarea
class="form-control"
rows="5"
placeholder="Your Message"></textarea>

</div>

<button
class="btn btn-warning w-100">

Send Message

</button>

</form>

</div>

</div>

</div>

</div>

</div>

</section>

<!-- PRODUCTS -->

<section class="py-5">

<div class="container">

<h2 class="text-center section-title mb-5">
Our Best Sellers
</h2>

<div class="row">

<div class="col-lg-4 mb-4">

<div class="card shadow">

<img src="uploads/products/pineapplemisu.jpeg" class="card-img-top">

<div class="card-body">

<h4>Pineapplemisu</h4>

<p>
A tropical twist on tiramisu with real pineapple chunks.
</p>

<div class="price">
₱149
</div>

<button class="btn btn-warning w-100 mt-3">
Add to Cart
</button>

</div>

</div>

</div>

<div class="col-lg-4 mb-4">

<div class="card shadow">

<img src="uploads/products/mangograham.jpeg" class="card-img-top">

<div class="card-body">

<h4>Mango Graham</h4>

<p>
Fresh mangoes layered with graham crackers and creamy filling.
</p>

<div class="price">
₱129
</div>

<button class="btn btn-warning w-100 mt-3">
Add to Cart
</button>

</div>

</div>

</div>

<div class="col-lg-4 mb-4">

<div class="card shadow">

<img src="uploads/products/tiramisu.jpeg" class="card-img-top">

<div class="card-body">

<h4>Tiramisu Graham</h4>

<p>
Rich and creamy coffee-flavored graham dessert.
</p>

<div class="price">
₱159
</div>

<button class="btn btn-warning w-100 mt-3">
Add to Cart
</button>

</div>

</div>

</div>

</div>

</div>

</section>

<!-- WHY US -->

<section class="py-5 bg-light">

<div class="container">

<h2 class="text-center section-title mb-5">
Why Choose Graham Delight?
</h2>

<div class="row text-center">

<div class="col-md-3">

<h1>🍍</h1>

<h5>Fresh Fruits</h5>

<p>Premium quality ingredients.</p>

</div>

<div class="col-md-3">

<h1>🥛</h1>

<h5>Creamy</h5>

<p>Rich and delicious every bite.</p>

</div>

<div class="col-md-3">

<h1>🚚</h1>

<h5>Fast Delivery</h5>

<p>Delivered fresh to your door.</p>

</div>

<div class="col-md-3">

<h1>❤️</h1>

<h5>Made with Love</h5>

<p>Perfect for every celebration.</p>

</div>

</div>

</div>

</section>


<!-- FOOTER -->

<footer class="pt-5 pb-3 text-white" style="background:#6F4E37;">

<div class="container">

<div class="row">

<div class="col-lg-4">

<h3 class="fw-bold">
🍰 Graham Delight
</h3>

<p>

Serving delicious homemade graham desserts made with premium ingredients and lots of love.

</p>

</div>

<div class="col-lg-2">

<h5>Quick Links</h5>

<ul class="list-unstyled">

<li><a href="index.php" class="text-white text-decoration-none">Home</a></li>

<li><a href="product.php" class="text-white text-decoration-none">Products</a></li>

<li><a href="about.php" class="text-white text-decoration-none">About</a></li>

<li><a href="contact.php" class="text-white text-decoration-none">Contact</a></li>

</ul>

</div>

<div class="col-lg-3">

<h5>Contact</h5>

<p>📍 Legazpi City, Albay</p>

<p>📞 +63 912 345 6789</p>

<p>📧 grahamdelight@email.com</p>

</div>

<div class="col-lg-3">

<h5>Follow Us</h5>

<p>📘 Facebook</p>

<p>📸 Instagram</p>

<p>🎵 TikTok</p>

</div>

</div>

<hr class="border-light">

<p class="text-center mb-0">

© 2026 Graham Delight. All Rights Reserved.

</p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>