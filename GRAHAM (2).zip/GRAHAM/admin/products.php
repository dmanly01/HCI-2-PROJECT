<?php
include '../config/database.php';

$search = "";

if(isset($_GET['search'])){
    $search = trim($_GET['search']);
}

$sql = "
SELECT
    products.*,
    categories.category_name,
    inventory.stock
FROM products
LEFT JOIN categories
ON products.category_id = categories.category_id
LEFT JOIN inventory
ON products.product_id = inventory.product_id
WHERE products.status != 'Inactive'
";

if($search != ""){
    $search = $conn->real_escape_string($search);

    $sql .= "
AND (
    products.product_name LIKE '%$search%'
    OR categories.category_name LIKE '%$search%'
)";
}

$sql .= " ORDER BY products.product_id DESC";

$result = $conn->query($sql);

if(!$result){
    die("SQL Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Products | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#f5f5f5;
}

.sidebar{
position:fixed;
left:0;
top:0;
width:250px;
height:100vh;
background:#6F4E37;
}

.sidebar h3{
color:white;
text-align:center;
padding:20px;
font-weight:bold;
}

.sidebar a{
display:block;
padding:15px 25px;
color:white;
text-decoration:none;
transition:.3s;
}

.sidebar a:hover,
.sidebar a.active{
background:#D4AF37;
}

.main{
margin-left:250px;
padding:30px;
}

.card{
border:none;
border-radius:15px;
}

table img{
width:80px;
height:80px;
object-fit:cover;
border-radius:10px;
}

.badge{
font-size:14px;
}

</style>

</head>

<body>

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.php">
<i class="bi bi-speedometer2"></i>
Dashboard
</a>

<a href="products.php" class="active">
<i class="bi bi-box-seam"></i>
Products
</a>

<a href="orders.php">
<i class="bi bi-cart"></i>
Orders
</a>

<a href="customers.php">
<i class="bi bi-people"></i>
Customers
</a>

<a href="inventory.php">
<i class="bi bi-boxes"></i>
Inventory
</a>

<a href="reports.php">
<i class="bi bi-bar-chart"></i>
Sales Report
</a>

<a href="../logout.php">
<i class="bi bi-box-arrow-right"></i>
Logout
</a>

</div>

<div class="main">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Product Management</h2>

<a href="add-product.php" class="btn btn-success">

<i class="bi bi-plus-circle"></i>

Add Product

</a>

</div>

<form method="GET">

<div class="input-group mb-4">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Product..."
value="<?php echo htmlspecialchars($search); ?>">

<button class="btn btn-primary">

<i class="bi bi-search"></i>

Search

</button>

</div>

</form>

<div class="card shadow">

<div class="card-body">

<?php if(isset($_GET['deleted'])){ ?>
<div class="alert alert-success alert-dismissible fade show">
    Product has been removed successfully.
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php } ?>

<div class="table-responsive">

<table class="table table-hover align-middle">

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Image</th>

<th>Product</th>

<th>Category</th>

<th>Price</th>

<th>Stock</th>

<th>Status</th>

<th>Featured</th>

<th width="170">Action</th>

</tr>

</thead>

<tbody>

<?php

if($result && $result->num_rows > 0){

    while($row = $result->fetch_assoc()){

?>

<tr>

    <td><?php echo $row['product_id']; ?></td>

    <td>

        <?php if(!empty($row['image']) && file_exists("../uploads/products/".$row['image'])){ ?>

            <img src="../uploads/products/<?php echo $row['image']; ?>" alt="Product">

        <?php }else{ ?>

            <img src="../assets/images/image.png" alt="Image">

        <?php } ?>

    </td>

    <td>

        <strong><?php echo htmlspecialchars($row['product_name']); ?></strong>

        <br>

        <small class="text-muted">

            <?php echo htmlspecialchars($row['description']); ?>

        </small>

    </td>

    <td>

        <?php echo htmlspecialchars($row['category_name']); ?>

    </td>

    <td>

        ₱<?php echo number_format($row['price'],2); ?>

    </td>

    <td>

        <?php echo $row['stock']; ?>

    </td>

    <td>

        <?php

        if($row['status']=="Available"){

            echo '<span class="badge bg-success">Available</span>';

        }else{

            echo '<span class="badge bg-danger">Out of Stock</span>';

        }

        ?>

    </td>

    <td>

        <?php

        if($row['featured']==1){

            echo '<span class="badge bg-warning text-dark">Featured</span>';

        }else{

            echo '<span class="badge bg-secondary">No</span>';

        }

        ?>

    </td>

    <td>

        <a
        href="edit-product.php?id=<?php echo $row['product_id']; ?>"
        class="btn btn-primary btn-sm">

            <i class="bi bi-pencil-square"></i>

        </a>

        <a
        href="delete-product.php?id=<?php echo $row['product_id']; ?>"
        class="btn btn-danger btn-sm"
        onclick="return confirm('Are you sure you want to delete this product?');">

            <i class="bi bi-trash"></i>

        </a>

    </td>

</tr>

<?php

    }

}else{

?>

<tr>

<td colspan="9" class="text-center">

No products found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

<div class="mt-3">

<?php

$totalProducts = 0;

$countQuery = $conn->query("SELECT COUNT(*) AS total FROM products");

if($countQuery){

    $countRow = $countQuery->fetch_assoc();

    $totalProducts = $countRow['total'];

}

?>

<div class="alert alert-info">

<strong>Total Products:</strong>

<?php echo $totalProducts; ?>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>