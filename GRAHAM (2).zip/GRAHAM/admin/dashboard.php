<?php
include '../config/database.php';

/* ==========================
   TOTAL PRODUCTS
========================== */

$productQuery = $conn->query("
SELECT COUNT(*) AS total
FROM products
");

$productRow = $productQuery->fetch_assoc();
$totalProducts = $productRow['total'];


/* ==========================
   TOTAL USERS
========================== */

$userQuery = $conn->query("
SELECT COUNT(*) AS total
FROM users
");

$userRow = $userQuery->fetch_assoc();
$totalUsers = $userRow['total'];


/* ==========================
   TOTAL ORDERS
========================== */

$orderQuery = $conn->query("
SELECT COUNT(*) AS total
FROM orders
");

$orderRow = $orderQuery->fetch_assoc();
$totalOrders = $orderRow['total'];


/* ==========================
   TOTAL SALES
========================== */

$salesQuery = $conn->query("
SELECT IFNULL(SUM(total_amount),0) AS total
FROM orders
WHERE status='Delivered'
");

$salesRow = $salesQuery->fetch_assoc();
$totalSales = $salesRow['total'];


/* ==========================
   LOW STOCK PRODUCTS
========================== */

$lowStock = $conn->query("
SELECT
    products.product_name,
    inventory.stock
FROM products
INNER JOIN inventory
ON products.product_id = inventory.product_id
WHERE inventory.stock <= 10
ORDER BY inventory.stock ASC
LIMIT 5
");


/* ==========================
   RECENT ORDERS
========================== */

$recentOrders = $conn->query("
SELECT
    orders.order_id,
    CONCAT(users.first_name,' ',users.last_name) AS customer_name,
    orders.total_amount,
    orders.status,
    orders.order_date
FROM orders
INNER JOIN users
ON orders.user_id = users.user_id
ORDER BY orders.order_date DESC
LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Dashboard | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#f5f5f5;
}

.sidebar{
position:fixed;
top:0;
left:0;
width:250px;
height:100vh;
background:#6F4E37;
padding-top:20px;
}

.sidebar h3{
color:#fff;
text-align:center;
margin-bottom:30px;
font-weight:bold;
}

.sidebar a{
display:block;
padding:15px 25px;
color:#fff;
text-decoration:none;
transition:.3s;
}

.sidebar a:hover,
.sidebar a.active{
background:#D4AF37;
color:#fff;
}

.main{
margin-left:250px;
padding:30px;
}

.card{
border:none;
border-radius:15px;
}

.stat-card{
color:#fff;
padding:20px;
}

.bg-sales{
background:#198754;
}

.bg-orders{
background:#0d6efd;
}

.bg-customers{
background:#dc3545;
}

.bg-products{
background:#6f42c1;
}

table img{
width:60px;
height:60px;
object-fit:cover;
border-radius:10px;
}

</style>

</head>

<body>

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.php" class="active">
<i class="bi bi-speedometer2"></i> Dashboard
</a>

<a href="products.php">
<i class="bi bi-box-seam"></i> Products
</a>

<a href="orders.php">
<i class="bi bi-cart-check"></i> Orders
</a>

<a href="customers.php">
<i class="bi bi-people"></i> Customers
</a>

<a href="inventory.php">
<i class="bi bi-boxes"></i> Inventory
</a>

<a href="reports.php">
<i class="bi bi-bar-chart"></i> Sales Report
</a>

<a href="settings.php">
<i class="bi bi-gear"></i> Settings
</a>

<a href="../logout.php">
<i class="bi bi-box-arrow-right"></i> Logout
</a>

</div>

<div class="main">

<h2 class="mb-4">
Dashboard
</h2>

<div class="row">

<div class="col-md-3 mb-4">

<div class="card stat-card bg-sales">

<h5>Total Sales</h5>

<h2>₱<?php echo number_format($totalSales,2); ?></h2>

</div>

</div>

<div class="col-md-3 mb-4">

<div class="card stat-card bg-orders">

<h5>Orders</h5>

<h2><?php echo $totalOrders; ?></h2>

</div>

</div>

<div class="col-md-3 mb-4">

<div class="card stat-card bg-customers">

<h5>Customers</h5>

<h2><?php echo $totalUsers; ?></h2>

</div>

</div>

<div class="col-md-3 mb-4">

<div class="card stat-card bg-products">

<h5>Products</h5>

<h2><?php echo $totalProducts; ?></h2>

</div>

</div>

</div>

<div class="card shadow">

<div class="card-header bg-white">

<h5 class="mb-0">
Recent Orders
</h5>

</div>

<div class="card-body">

<div class="table-responsive">

<table class="table align-middle">

<thead>

<tr>

<th>Order ID</th>

<th>Customer</th>

<th>Product</th>

<th>Total</th>

<th>Status</th>

</tr>

</thead>

<tbody>

<?php
if($recentOrders->num_rows > 0){

while($row = $recentOrders->fetch_assoc()){
?>

<tr>

<td>#<?php echo $row['order_id']; ?></td>

<td><?php echo htmlspecialchars($row['customer_name']); ?></td>

<td>—</td>

<td>₱<?php echo number_format($row['total_amount'],2); ?></td>

<td>

<?php

if($row['status']=="Delivered"){

echo '<span class="badge bg-success">Delivered</span>';

}elseif($row['status']=="Preparing"){

echo '<span class="badge bg-warning text-dark">Preparing</span>';

}else{

echo '<span class="badge bg-secondary">'.$row['status'].'</span>';

}

?>

</td>

</tr>

<?php

}

}else{

?>

<tr>

<td colspan="5" class="text-center">

No recent orders.

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>