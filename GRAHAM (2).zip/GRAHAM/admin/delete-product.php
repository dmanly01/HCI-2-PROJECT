<?php
include '../config/database.php';

if (!isset($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = (int)$_GET['id'];

$conn->begin_transaction();

try {

    // Delete inventory record
    $stmt = $conn->prepare("DELETE FROM inventory WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->close();

    // Delete all order items that use this product
    $stmt = $conn->prepare("DELETE FROM order_items WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->close();

    // Delete the product
    $stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);

    if (!$stmt->execute()) {
        throw new Exception($stmt->error);
    }

    $stmt->close();

    $conn->commit();

    header("Location: products.php?deleted=1");
    exit();

} catch (Exception $e) {

    $conn->rollback();

    die("Delete Failed: " . $e->getMessage());

}
?>