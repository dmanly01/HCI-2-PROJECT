<?php
include '../config/database.php';

$search = "";
$statusFilter = "";

/* ==========================
   UPDATE ORDER STATUS
========================== */
if(isset($_POST['update_status'])){

    $order_id = (int)$_POST['order_id'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("
        UPDATE orders
        SET status=?
        WHERE order_id=?
    ");

    $stmt->bind_param("si",$status,$order_id);
    $stmt->execute();

    header("Location: orders.php?updated=1");
    exit();
}


/* ==========================
   DELETE ORDER
========================== */
if(isset($_GET['delete'])){

    $order_id = (int)$_GET['delete'];

    $stmt = $conn->prepare("
        DELETE FROM order_items
        WHERE order_id=?
    ");
    $stmt->bind_param("i",$order_id);
    $stmt->execute();

    $stmt = $conn->prepare("
        DELETE FROM orders
        WHERE order_id=?
    ");
    $stmt->bind_param("i",$order_id);
    $stmt->execute();

    header("Location: orders.php?deleted=1");
    exit();
}


/* ==========================
   SEARCH
========================== */
if(isset($_GET['search'])){
    $search = trim($_GET['search']);
}


/* ==========================
   FILTER
========================== */
if(isset($_GET['status'])){
    $statusFilter = trim($_GET['status']);
}


/* ==========================
   LOAD ORDERS
========================== */

$sql = "
SELECT
orders.order_id,
orders.user_id,
orders.total_amount,
orders.payment_method,
orders.status,
orders.order_date,
users.first_name,
users.last_name
FROM orders
INNER JOIN users
ON orders.user_id = users.user_id
WHERE 1=1
";

if($search!=""){

    $search = $conn->real_escape_string($search);

    $sql .= "
    AND
    (
        users.first_name LIKE '%$search%'
        OR
        users.last_name LIKE '%$search%'
        OR
        orders.order_id LIKE '%$search%'
    )
    ";

}

if($statusFilter!="" && $statusFilter!="All"){

    $statusFilter = $conn->real_escape_string($statusFilter);

    $sql .= "
    AND orders.status='$statusFilter'
    ";

}

$sql .= "
ORDER BY orders.order_date DESC
";

$result = $conn->query($sql);

if(!$result){
    die($conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Orders | Graham Delight Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#f5f5f5;
}

.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:250px;
    height:100vh;
    background:#6F4E37;
}

.sidebar h3{
    color:#fff;
    text-align:center;
    padding:20px;
    font-weight:bold;
}

.sidebar a{
    display:block;
    padding:15px 25px;
    color:#fff;
    text-decoration:none;
}

.sidebar a:hover,
.sidebar a.active{
    background:#D4AF37;
}

.main{
    margin-left:250px;
    padding:30px;
}

.card{
    border:none;
    border-radius:15px;
}
.table td,
.table th{
    vertical-align: middle;
    white-space: nowrap;
}
.products-column{
    white-space: normal;
}

</style>

</head>

<body>

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.php">
<i class="bi bi-speedometer2"></i> Dashboard
</a>

<a href="products.php">
<i class="bi bi-box-seam"></i> Products
</a>

<a href="orders.php" class="active">
<i class="bi bi-cart-check"></i> Orders
</a>

<a href="customers.php">
<i class="bi bi-people"></i> Customers
</a>

<a href="inventory.php">
<i class="bi bi-boxes"></i> Inventory
</a>

<a href="reports.php">
<i class="bi bi-bar-chart"></i> Reports
</a>

<a href="../logout.php">
<i class="bi bi-box-arrow-right"></i> Logout
</a>

</div>

<div class="main">

<h2 class="mb-4">
Order Management
</h2>

<div class="card shadow">

<div class="card-body">

<?php if(isset($_GET['updated'])){ ?>

<div class="alert alert-success alert-dismissible fade show">
Order status updated successfully.
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>

<?php } ?>

<?php if(isset($_GET['deleted'])){ ?>

<div class="alert alert-danger alert-dismissible fade show">
Order deleted successfully.
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>

<?php } ?>

<form method="GET">

<div class="row mb-3">

<div class="col-md-5">

<input
type="text"
name="search"
class="form-control"
placeholder="Search customer or Order ID"
value="<?php echo htmlspecialchars($search); ?>">

</div>

<div class="col-md-3">

<select
name="status"
class="form-select">

<option value="">All Status</option>

<option value="Pending" <?php if($statusFilter=="Pending") echo "selected"; ?>>Pending</option>

<option value="Preparing" <?php if($statusFilter=="Preparing") echo "selected"; ?>>Preparing</option>

<option value="Out for Delivery" <?php if($statusFilter=="Out for Delivery") echo "selected"; ?>>Out for Delivery</option>

<option value="Delivered" <?php if($statusFilter=="Delivered") echo "selected"; ?>>Delivered</option>

<option value="Cancelled" <?php if($statusFilter=="Cancelled") echo "selected"; ?>>Cancelled</option>

</select>

</div>

<div class="col-md-2">

<button class="btn btn-primary w-100">
Search
</button>

</div>

</div>

</form>

<div class="table-responsive">

<table class="table table-hover align-middle">

<thead class="table-dark">

<tr>

<th style="white-space: nowrap;">Order ID</th>
<th style="white-space: nowrap;">Customer</th>
<th style="white-space: nowrap;">Products</th>
<th style="white-space: nowrap;">Total</th>
<th style="white-space: nowrap;">Payment</th>
<th style="white-space: nowrap;">Status</th>
<th style="white-space: nowrap;">Date</th>
<th width="220">Actions</th>

</tr>

</thead>

<tbody>

<?php

if($result->num_rows > 0){

    while($row = $result->fetch_assoc()){

        $productList = [];

        $stmtProducts = $conn->prepare("
            SELECT
                products.product_name,
                order_items.quantity
            FROM order_items
            INNER JOIN products
                ON order_items.product_id = products.product_id
            WHERE order_items.order_id = ?
        ");

        $stmtProducts->bind_param("i", $row['order_id']);
        $stmtProducts->execute();
        $productResult = $stmtProducts->get_result();

        while($p = $productResult->fetch_assoc()){
            $productList[] = htmlspecialchars($p['product_name']) . " x" . $p['quantity'];
        }
?>

<tr>

<td>#<?php echo $row['order_id']; ?></td>

<td>
<?php echo htmlspecialchars($row['first_name']." ".$row['last_name']); ?>
</td>

<td class="products-column">
    <?php echo implode("<br>", $productList); ?>
</td>

<td>
₱<?php echo number_format($row['total_amount'],2); ?>
</td>

<td>
<?php echo htmlspecialchars($row['payment_method']); ?>
</td>

<td>

<form method="POST" class="d-flex">

<input
type="hidden"
name="order_id"
value="<?php echo $row['order_id']; ?>">

<select
name="status"
class="form-select form-select-sm me-2"
style="min-width:170px;">

<option value="Pending" <?php if($row['status']=="Pending") echo "selected"; ?>>Pending</option>

<option value="Preparing" <?php if($row['status']=="Preparing") echo "selected"; ?>>Preparing</option>

<option value="Out for Delivery" <?php if($row['status']=="Out for Delivery") echo "selected"; ?>>Out for Delivery</option>

<option value="Delivered" <?php if($row['status']=="Delivered") echo "selected"; ?>>Delivered</option>

<option value="Cancelled" <?php if($row['status']=="Cancelled") echo "selected"; ?>>Cancelled</option>

</select>

<button
type="submit"
name="update_status"
class="btn btn-success btn-sm">

<i class="bi bi-check"></i>

</button>

</form>

</td>

<td>
<?php echo date("M d, Y", strtotime($row['order_date'])); ?>
</td>

<td>

<a
href="view-order.php?id=<?php echo $row['order_id']; ?>"
class="btn btn-info btn-sm">

<i class="bi bi-eye"></i>

</a>

<a
href="orders.php?delete=<?php echo $row['order_id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Are you sure you want to delete this order?');">

<i class="bi bi-trash"></i>

</a>

</td>

</tr>

<?php

    }

}else{

?>

<tr>

<td colspan="8" class="text-center">

No orders found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>