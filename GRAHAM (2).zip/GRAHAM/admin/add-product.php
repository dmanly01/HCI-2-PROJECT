<?php
include_once '../config/database.php';

if (!isset($conn)) {
    die("Database connection failed. Check config/database.php");
}

$message = "";

if(isset($_POST['save'])){

    $name = trim($_POST['product_name']);
    $category = (int)$_POST['category'];
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    $description = trim($_POST['description']);
    $status = $_POST['status'];
    $featured = isset($_POST['featured']) ? 1 : 0;

    $image = "";

    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){

        $image = basename($_FILES['image']['name']);

        $target = "../uploads/products/" . $image;

        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }

    $sql = "INSERT INTO products
    (category_id, product_name, description, price, image, status, featured)
    VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if(!$stmt){
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        "issdssi",
        $category,
        $name,
        $description,
        $price,
        $image,
        $status,
        $featured
    );

    if($stmt->execute()){

        $product_id = $conn->insert_id;

        $inventory = $conn->prepare("INSERT INTO inventory(product_id, stock) VALUES (?, ?)");

        $inventory->bind_param("ii", $product_id, $stock);

        $inventory->execute();

        $message = "<div class='alert alert-success'>Product Added Successfully!</div>";

    } else {

        $message = "<div class='alert alert-danger'>".$stmt->error."</div>";

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add Product | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#f5f5f5;
}

.sidebar{
position:fixed;
top:0;
left:0;
width:250px;
height:100vh;
background:#6F4E37;
}

.sidebar h3{
color:#fff;
text-align:center;
padding:20px;
font-weight:bold;
}

.sidebar a{
display:block;
padding:15px 25px;
color:#fff;
text-decoration:none;
transition:.3s;
}

.sidebar a:hover,
.sidebar a.active{
background:#D4AF37;
}

.main{
margin-left:250px;
padding:30px;
}

.card{
border:none;
border-radius:15px;
}

.btn-save{
background:#198754;
color:white;
font-weight:bold;
}

.btn-save:hover{
background:#157347;
color:white;
}

.btn-cancel{
background:#6c757d;
color:white;
font-weight:bold;
}

.preview{
width:200px;
height:200px;
border:2px dashed #ccc;
display:flex;
justify-content:center;
align-items:center;
overflow:hidden;
border-radius:10px;
margin-top:10px;
}

.preview img{
width:100%;
height:100%;
object-fit:cover;
display:none;
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.php">
<i class="bi bi-speedometer2"></i> Dashboard
</a>

<a href="products.php" class="active">
<i class="bi bi-box-seam"></i> Products
</a>

<a href="orders.php">
<i class="bi bi-cart"></i> Orders
</a>

<a href="customers.php">
<i class="bi bi-people"></i> Customers
</a>

<a href="inventory.php">
<i class="bi bi-boxes"></i> Inventory
</a>

<a href="reports.php">
<i class="bi bi-bar-chart"></i> Sales Report
</a>

<a href="../index.html">
<i class="bi bi-box-arrow-right"></i> Logout
</a>

</div>

<!-- MAIN -->

<div class="main">

<h2 class="mb-4">
Add New Product
</h2>

<div class="card shadow">

<div class="card-body">

<?php if(!empty($message)) echo $message; ?>

<form method="POST" enctype="multipart/form-data">

<div class="row">

<div class="col-md-6 mb-3">

<label class="form-label">
Product Name
</label>

<input type="text"
name="product_name"
class="form-control"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">Category</label>

<select name="category" class="form-select">

<option value="1">Fruit</option>
<option value="2">Coffee</option>
<option value="3">Chocolate</option>
<option value="4">Special</option>

</select>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">Price</label>

<input
type="number"
name="price"
class="form-control"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Stock Quantity
</label>

<input
type="number"
name="stock"
class="form-control">

</div>

<div class="col-12 mb-3">

<label class="form-label">
Description
</label>

<textarea
name="description"
class="form-control"></textarea>

</div>

<div class="col-md-6">

<label class="form-label">
Upload Product Image
</label>

<input
type="file"
id="imageInput"
name="image"
class="form-control"
required>

<div class="preview">

<img id="previewImage">

<span id="placeholderText">
Image Preview
</span>

</div>

</div>

<div class="col-md-6">

<label class="form-label">
Product Status
</label>

<select name="status" class="form-select">
    <option value="Available">Available</option>
    <option value="Out of Stock">Out of Stock</option>
    <option value="Inactive">Inactive</option>
</select>

<br>

<div class="form-check form-switch">

<input
type="checkbox"
name="featured"
class="form-check-input">

<label class="form-check-label">

Featured Product

</label>

</div>

</div>

<div class="col-12 mt-4">

<button
type="submit"
name="save"
class="btn btn-success">

Save Product

</button>

<a
href="products.php"
class="btn btn-cancel">

Cancel

</a>

</div>

</div>

</form>

</div>

</div>

</div>

<script>

const imageInput=document.getElementById("imageInput");
const preview=document.getElementById("previewImage");
const placeholder=document.getElementById("placeholderText");

imageInput.addEventListener("change",function(){

const file=this.files[0];

if(file){

const reader=new FileReader();

reader.onload=function(e){

preview.src=e.target.result;

preview.style.display="block";

placeholder.style.display="none";

}

reader.readAsDataURL(file);

}

});

</script>

</body>

</html>