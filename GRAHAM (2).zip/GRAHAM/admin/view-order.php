<?php
include '../config/database.php';

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$order_id = (int)$_GET['id'];

/* ==========================
   GET ORDER + CUSTOMER + PAYMENT
========================== */

$sql = "
SELECT
    orders.*,
    users.first_name,
    users.last_name,
    users.email,
    users.contact,
    users.address,
    payments.payment_method,
    payments.payment_status,
    payments.payment_date
FROM orders

INNER JOIN users
ON orders.user_id = users.user_id

LEFT JOIN payments
ON orders.order_id = payments.order_id

WHERE orders.order_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Order not found.");
}

$order = $result->fetch_assoc();

/* ==========================
   GET ORDER ITEMS
========================== */

$itemSQL = "
SELECT
    products.product_name,
    order_items.quantity,
    order_items.price
FROM order_items

INNER JOIN products
ON order_items.product_id = products.product_id

WHERE order_items.order_id = ?
";

$itemStmt = $conn->prepare($itemSQL);
$itemStmt->bind_param("i", $order_id);
$itemStmt->execute();

$orderItems = $itemStmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>View Order | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#f5f5f5;
}

.container{
    max-width:1100px;
    margin:40px auto;
}

.card{
    border:none;
    border-radius:15px;
}

.table th,
.table td{
    vertical-align:middle;
}

</style>

</head>

<body>

<div class="container">

<div class="card shadow">

<div class="card-header bg-dark text-white">

<h3 class="mb-0">
<i class="bi bi-receipt"></i>
Order Details
</h3>

</div>

<div class="card-body">

<div class="row">

<div class="col-md-6">

<h5 class="mb-3">
Order Information
</h5>

<p><strong>Order ID:</strong> #<?php echo $order['order_id']; ?></p>

<p><strong>Order Date:</strong>
<?php echo date("F d, Y", strtotime($order['order_date'])); ?>
</p>

<p><strong>Status:</strong>

<span class="badge bg-success">

<?php echo $order['status']; ?>

</span>

</p>

</div>

<div class="col-md-6">

<h5 class="mb-3">
Payment Information
</h5>

<p><strong>Method:</strong>

<?php echo $order['payment_method']; ?>

</p>

<p><strong>Status:</strong>

<?php echo $order['payment_status']; ?>

</p>

<p><strong>Date:</strong>

<?php echo date("F d, Y", strtotime($order['payment_date'])); ?>

</p>

</div>

</div>

<hr>

<h5 class="mb-3">
Customer Information
</h5>

<p><strong>Name:</strong>

<?php echo $order['first_name']." ".$order['last_name']; ?>

</p>

<p><strong>Email:</strong>

<?php echo $order['email']; ?>

</p>

<p><strong>Contact:</strong>

<?php echo $order['contact']; ?>

</p>

<p><strong>Address:</strong>

<?php echo $order['address']; ?>

</p>

<hr>

<h5 class="mb-3">
Ordered Products
</h5>

<div class="table-responsive">

<table class="table table-bordered">

<thead class="table-dark">

<tr>

<th>Product</th>

<th width="120">Quantity</th>

<th width="150">Price</th>

<th width="150">Subtotal</th>

</tr>

</thead>

<tbody>

<?php

$grandTotal = 0;

while($item = $orderItems->fetch_assoc()){

$subtotal = $item['quantity'] * $item['price'];

$grandTotal += $subtotal;

?>

<tr>

<td>
<?php echo htmlspecialchars($item['product_name']); ?>
</td>

<td>
<?php echo $item['quantity']; ?>
</td>

<td>

₱<?php echo number_format($item['price'],2); ?>

</td>

<td>

₱<?php echo number_format($subtotal,2); ?>

</td>

</tr>

<?php

}

?>

</tbody>

<tfoot>

<tr>

<th colspan="3" class="text-end">

Grand Total

</th>

<th>

₱<?php echo number_format($grandTotal,2); ?>

</th>

</tr>

</tfoot>

</table>

</div>

<hr>

<div class="d-flex justify-content-between mt-4">

<a
href="orders.php"
class="btn btn-secondary">

<i class="bi bi-arrow-left"></i>

Back to Orders

</a>

<button
onclick="window.print()"
class="btn btn-primary">

<i class="bi bi-printer"></i>

Print Receipt

</button>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>