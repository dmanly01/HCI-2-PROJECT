<?php
include '../config/database.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = (int) $_GET['id'];
$message = "";

/* ==========================
   UPDATE PRODUCT
========================== */

if (isset($_POST['update'])) {

    $name        = trim($_POST['product_name']);
    $category    = (int) $_POST['category'];
    $price       = (float) $_POST['price'];
    $stock       = (int) $_POST['stock'];
    $description = trim($_POST['description']);
    $status      = $_POST['status'];
    $featured    = isset($_POST['featured']) ? 1 : 0;

    $image = $_POST['old_image'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {

        $image = time() . "_" . basename($_FILES['image']['name']);

        move_uploaded_file(
            $_FILES['image']['tmp_name'],
            "../uploads/products/" . $image
        );
    }

    $update = $conn->prepare("
        UPDATE products
        SET
            category_id = ?,
            product_name = ?,
            description = ?,
            price = ?,
            image = ?,
            status = ?,
            featured = ?
        WHERE product_id = ?
    ");

    $update->bind_param(
        "issdssii",
        $category,
        $name,
        $description,
        $price,
        $image,
        $status,
        $featured,
        $product_id
    );

    if ($update->execute()) {

        $stockUpdate = $conn->prepare("
            UPDATE inventory
            SET stock = ?
            WHERE product_id = ?
        ");

        $stockUpdate->bind_param(
            "ii",
            $stock,
            $product_id
        );

        $stockUpdate->execute();

        $message = "
        <div class='alert alert-success'>
            <i class='bi bi-check-circle-fill'></i>
            Product updated successfully.
        </div>";
    } else {

        $message = "
        <div class='alert alert-danger'>
            ".$update->error."
        </div>";
    }
}

/* ==========================
   LOAD PRODUCT
========================== */

$productQuery = $conn->prepare("
SELECT
    products.*,
    inventory.stock
FROM products
LEFT JOIN inventory
ON products.product_id = inventory.product_id
WHERE products.product_id = ?
");

$productQuery->bind_param("i", $product_id);

$productQuery->execute();

$product = $productQuery->get_result()->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

/* ==========================
   LOAD CATEGORIES
========================== */

$categories = $conn->query("
SELECT *
FROM categories
ORDER BY category_name ASC
");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Product | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#f5f5f5;
}

.sidebar{
position:fixed;
left:0;
top:0;
width:250px;
height:100vh;
background:#6F4E37;
}

.sidebar h3{
padding:20px;
text-align:center;
color:white;
}

.sidebar a{
display:block;
padding:15px 25px;
color:white;
text-decoration:none;
}

.sidebar a:hover,
.sidebar a.active{
background:#D4AF37;
}

.main{
margin-left:250px;
padding:30px;
}

.card{
border:none;
border-radius:15px;
}

.preview{
width:220px;
height:220px;
border-radius:15px;
overflow:hidden;
border:2px solid #ddd;
}

.preview img{
width:100%;
height:100%;
object-fit:cover;
}

.btn-save{
background:#198754;
color:white;
font-weight:bold;
}

.btn-save:hover{
background:#157347;
color:white;
}

</style>

</head>

<body>

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.html">
<i class="bi bi-speedometer2"></i> Dashboard
</a>

<a href="products.php" class="active">
<i class="bi bi-box-seam"></i> Products
</a>

<a href="orders.html">
<i class="bi bi-cart"></i> Orders
</a>

<a href="customers.html">
<i class="bi bi-people"></i> Customers
</a>

<a href="inventory.html">
<i class="bi bi-boxes"></i> Inventory
</a>

<a href="reports.html">
<i class="bi bi-bar-chart"></i> Reports
</a>

<a href="../index.html">
<i class="bi bi-box-arrow-right"></i> Logout
</a>

</div>

<div class="main">

<h2 class="mb-4">
Edit Product
</h2>

<div class="card shadow">

<div class="card-body">

<?php if(!empty($message)) echo $message; ?>

<form method="POST" enctype="multipart/form-data">

<input
type="hidden"
name="old_image"
value="<?php echo $product['image']; ?>">

<div class="row">

<div class="col-md-8">

<div class="mb-3">

<label class="form-label">
Product Name
</label>

<input
type="text"
name="product_name"
class="form-control"
required
value="<?php echo htmlspecialchars($product['product_name']); ?>">

</div>

<div class="row">

<div class="col-md-6 mb-3">

<label class="form-label">
Category
</label>

<select
name="category"
class="form-select"
required>

<?php while($cat = $categories->fetch_assoc()){ ?>

<option
value="<?php echo $cat['category_id']; ?>"
<?php if($cat['category_id']==$product['category_id']) echo "selected"; ?>>

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php } ?>

</select>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Price
</label>

<input
type="number"
step="0.01"
name="price"
class="form-control"
required
value="<?php echo $product['price']; ?>">

</div>

</div>

<div class="mb-3">

<label class="form-label">
Stock Quantity
</label>

<input
type="number"
name="stock"
class="form-control"
required
value="<?php echo $product['stock']; ?>">

</div>

<div class="mb-3">

<label class="form-label">
Description
</label>

<textarea
name="description"
rows="6"
class="form-control"><?php echo htmlspecialchars($product['description']); ?></textarea>

</div>

<div class="mb-3">

<label class="form-label">
Status
</label>

<select
name="status"
class="form-select">

<option
value="Available"
<?php if($product['status']=="Available") echo "selected"; ?>>

Available

</option>

<option
value="Out of Stock"
<?php if($product['status']=="Out of Stock") echo "selected"; ?>>

Out of Stock

</option>

</select>

</div>

<div class="form-check form-switch mb-3">

<input
type="checkbox"
class="form-check-input"
name="featured"
<?php if($product['featured']==1) echo "checked"; ?>>

<label class="form-check-label">

Featured Product

</label>

</div>

</div>

<div class="col-md-4">

<label class="form-label">

Current Image

</label>

<div class="preview mb-3">

<?php

$image="../uploads/products/".$product['image'];

if(!empty($product['image']) && file_exists($image)){

?>

<img
id="previewImage"
src="<?php echo $image; ?>">

<?php } else { ?>

<img
id="previewImage"
src="../assets/images/image.png">

<?php } ?>

</div>

<input
type="file"
id="imageInput"
name="image"
class="form-control">

</div>

<div class="col-12 mt-4">

<button
type="submit"
name="update"
class="btn btn-save">

<i class="bi bi-check-circle"></i>

Update Product

</button>

<a
href="products.php"
class="btn btn-secondary">

Cancel

</a>

</div>

</div>

</form>

</div>

</div>

</div>

<script>

const imageInput = document.getElementById("imageInput");
const previewImage = document.getElementById("previewImage");

imageInput.addEventListener("change", function(){

    if(this.files && this.files[0]){

        const reader = new FileReader();

        reader.onload = function(e){

            previewImage.src = e.target.result;

        }

        reader.readAsDataURL(this.files[0]);

    }

});

</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>

</body>

</html>