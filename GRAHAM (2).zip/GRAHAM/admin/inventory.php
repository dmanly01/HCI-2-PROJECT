<?php
include '../config/database.php';

$search = "";

/* ==========================
   UPDATE STOCK
========================== */

if (isset($_POST['save_stock'])) {

    $product_id = (int)$_POST['product_id'];
    $stock = (int)$_POST['stock'];

    $update = $conn->prepare("
        UPDATE inventory
        SET stock = ?
        WHERE product_id = ?
    ");

    $update->bind_param("ii", $stock, $product_id);
    $update->execute();

    header("Location: inventory.php?updated=1");
    exit();
}

/* ==========================
   SEARCH
========================== */

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

$sql = "
SELECT
    products.product_id,
    products.product_name,
    products.image,
    categories.category_name,
    inventory.stock
FROM products
LEFT JOIN categories
ON products.category_id = categories.category_id
LEFT JOIN inventory
ON products.product_id = inventory.product_id
";

if ($search != "") {

    $search = $conn->real_escape_string($search);

    $sql .= "
    WHERE
        products.product_name LIKE '%$search%'
        OR categories.category_name LIKE '%$search%'
    ";
}

$sql .= " ORDER BY products.product_name ASC";

$result = $conn->query($sql);

if (!$result) {
    die("SQL Error: " . $conn->error);
}

/* ==========================
   TOTAL PRODUCTS
========================== */

$totalInventory = $conn->query("
SELECT COUNT(*) AS total
FROM inventory
");

$totalRow = $totalInventory->fetch_assoc();
$totalItems = $totalRow['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Inventory | Graham Delight Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#f5f5f5;
}

.sidebar{
position:fixed;
left:0;
top:0;
width:250px;
height:100vh;
background:#6F4E37;
}

.sidebar h3{
color:#fff;
padding:20px;
text-align:center;
font-weight:bold;
}

.sidebar a{
display:block;
padding:15px 25px;
color:white;
text-decoration:none;
transition:.3s;
}

.sidebar a:hover,
.sidebar a.active{
background:#D4AF37;
}

.main{
    margin-left:250px;
    padding:30px;
    width:calc(100% - 250px);
    box-sizing:border-box;
}

.card{
border:none;
border-radius:15px;
}



.badge-low{
background:#ffc107;
color:#000;
}

.badge-out{
background:#dc3545;
}

.badge-stock{
background:#198754;
}
.inventory-product-image {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 5px;
}
/* Total Inventory Items - compact */
.mt-3 .alert.alert-info {
    padding: 10px 16px !important;
    margin-top: 8px !important;
    margin-bottom: 0 !important;
    font-size: 16px !important;
    line-height: 1.3 !important;
    min-height: auto !important;
}
/* Total Inventory Items */
/* Total Inventory Items - FIX */
.inventory-total-box{
    margin-left: 250px !important;
    width: calc(100% - 250px) !important;
    box-sizing: border-box !important;

    padding: 10px 16px !important;
    margin-top: 8px !important;
    margin-bottom: 0 !important;

    font-size: 16px !important;
    line-height: 1.3 !important;
}

</style>

</head>

<body>

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.php">
<i class="bi bi-speedometer2"></i> Dashboard
</a>

<a href="products.php">
<i class="bi bi-box-seam"></i> Products
</a>

<a href="orders.php">
<i class="bi bi-cart-check"></i> Orders
</a>

<a href="customers.php">
<i class="bi bi-people"></i> Customers
</a>

<a href="inventory.php" class="active">
<i class="bi bi-boxes"></i> Inventory
</a>

<a href="reports.php">
<i class="bi bi-bar-chart"></i> Reports
</a>

<a href="../logout.php">
<i class="bi bi-box-arrow-right"></i> Logout
</a>

</div>

<div class="main">

<h2 class="mb-4">

Inventory Management

</h2>

<div class="card shadow">

<div class="card-body">

SUCCESS MESSAGE

SEARCH FORM

<div class="table-responsive">

<table>

...

</table>

</div>

</div>


<?php if(isset($_GET['updated'])){ ?>

<div class="alert alert-success alert-dismissible fade show" role="alert">

<i class="bi bi-check-circle-fill"></i>

Stock updated successfully!

<button
type="button"
class="btn-close"
data-bs-dismiss="alert">
</button>

</div>

<?php } ?>

<form method="GET">

<div class="row mb-4">

<div class="col-md-4">

<div class="input-group">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Product..."
value="<?php echo htmlspecialchars($search); ?>">

<button
class="btn btn-primary">

<i class="bi bi-search"></i>

Search

</button>

</div>

</div>

</div>

</form>

</div>

<div class="table-responsive">

<table class="table table-hover align-middle">

<thead class="table-dark">

<tr>

<th>Image</th>

<th>Product</th>

<th>Category</th>

<th>Current Stock</th>

<th>Status</th>

<th>Update Stock</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php

if($result->num_rows > 0){

while($row = $result->fetch_assoc()){

?>

<tr>

<td>

<?php

$image = "../uploads/products/" . $row['image'];

if(!empty($row['image']) && file_exists($image)){

?>

<img
src="<?php echo $image; ?>"
class="inventory-product-image">

<?php }else{ ?>

<img
src="../assets/images/image.png"
class="inventory-product-image">




<?php } ?>

</td>

<td>

<strong>

<?php echo htmlspecialchars($row['product_name']); ?>

</strong>

</td>

<td>

<?php echo htmlspecialchars($row['category_name']); ?>

</td>

<td>

<?php echo $row['stock']; ?>

</td>

<td>

<?php

if($row['stock'] == 0){

echo '<span class="badge bg-danger">Out of Stock</span>';

}elseif($row['stock'] <= 10){

echo '<span class="badge bg-warning text-dark">Low Stock</span>';

}else{

echo '<span class="badge bg-success">In Stock</span>';

}

?>

</td>

<td>

<form method="POST" class="d-flex">

<input
type="hidden"
name="product_id"
value="<?php echo $row['product_id']; ?>">

<input
type="number"
name="stock"
class="form-control me-2"
value="<?php echo $row['stock']; ?>"
min="0"
style="width:90px;">

</td>

<td>

<button
type="submit"
name="save_stock"
class="btn btn-success btn-sm">

<i class="bi bi-check-circle"></i>

Save

</button>

</form>

</td>

</tr>

<?php

}

}else{

?>

<tr>

<td colspan="7" class="text-center">

No inventory found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

<div class="mt-3">

<div class="alert alert-info inventory-total-box">

<strong>Total Inventory Items:</strong>

<?php echo $totalItems; ?>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>