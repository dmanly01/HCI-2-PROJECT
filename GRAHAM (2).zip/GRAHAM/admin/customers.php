<?php
include '../config/database.php';

$search = "";

/* ==========================
   DELETE CUSTOMER
========================== */

if(isset($_GET['delete'])){

    $user_id = (int)$_GET['delete'];

    $stmt = $conn->prepare("
        UPDATE users
        SET status='Inactive'
        WHERE user_id=?
    ");

    $stmt->bind_param("i",$user_id);
    $stmt->execute();

    header("Location: customers.php?deleted=1");
    exit();
}

/* ==========================
   SEARCH
========================== */

if(isset($_GET['search'])){
    $search = trim($_GET['search']);
}

$sql = "
SELECT *
FROM users
WHERE role='Customer'
AND status='Active'
";

if($search != ""){

    $search = $conn->real_escape_string($search);

    $sql .= "
    AND(
        first_name LIKE '%$search%'
        OR last_name LIKE '%$search%'
        OR email LIKE '%$search%'
    )";
}

$sql .= "
ORDER BY created_at DESC";

$result = $conn->query($sql);

if(!$result){
    die("SQL Error: ".$conn->error);
}

/* ==========================
   TOTAL CUSTOMERS
========================== */

$totalCustomerQuery = $conn->query("
SELECT COUNT(*) AS total
FROM users
WHERE role='Customer'
");

$totalCustomers = $totalCustomerQuery->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Customers | Graham Delight Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#f5f5f5;
}

.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:250px;
    height:100vh;
    background:#6F4E37;
}

.sidebar h3{
    color:#fff;
    text-align:center;
    padding:20px;
    font-weight:bold;
}

.sidebar a{
    display:block;
    padding:15px 25px;
    color:#fff;
    text-decoration:none;
    transition:.3s;
}

.sidebar a:hover,
.sidebar a.active{
    background:#D4AF37;
}

.main{
    margin-left:250px;
    padding:30px;
}

.card{
    border:none;
    border-radius:15px;
}

.table th,
.table td{
    vertical-align:middle;
}

</style>

</head>

<body>

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.php">
<i class="bi bi-speedometer2"></i> Dashboard
</a>

<a href="products.php">
<i class="bi bi-box-seam"></i> Products
</a>

<a href="orders.php">
<i class="bi bi-cart-check"></i> Orders
</a>

<a href="customers.php" class="active">
<i class="bi bi-people"></i> Customers
</a>

<a href="inventory.php">
<i class="bi bi-boxes"></i> Inventory
</a>

<a href="reports.php">
<i class="bi bi-bar-chart"></i> Reports
</a>

<a href="../logout.php">
<i class="bi bi-box-arrow-right"></i> Logout
</a>

</div>

<div class="main">

<h2 class="mb-4">Customer Management</h2>

<div class="row mb-4">

<div class="col-md-3">

<div class="card shadow">

<div class="card-body text-center">

<h6>Total Customers</h6>

<h2 class="text-primary">

<?php echo $totalCustomers; ?>

</h2>

</div>

</div>

</div>

</div>

<?php if(isset($_GET['deleted'])){ ?>

<div class="alert alert-success alert-dismissible fade show">

Customer deleted successfully.

<button
type="button"
class="btn-close"
data-bs-dismiss="alert">
</button>

</div>

<?php } ?>

<form method="GET">

<div class="row mb-3">

<div class="col-md-5">

<input
type="text"
name="search"
class="form-control"
placeholder="Search customer..."
value="<?php echo htmlspecialchars($search); ?>">

</div>

<div class="col-md-2">

<button class="btn btn-primary w-100">

<i class="bi bi-search"></i>

Search

</button>

</div>

</div>

</form>

<div class="card shadow">

<div class="card-body">

<div class="table-responsive">

<table class="table table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Contact</th>
<th>Address</th>
<th>Date Registered</th>
<th width="150">Action</th>

</tr>

</thead>

<tbody>

<?php

if($result->num_rows > 0){

while($row = $result->fetch_assoc()){

?>

<tr>

<td>

<?php echo $row['user_id']; ?>

</td>

<td>

<?php echo htmlspecialchars($row['first_name']." ".$row['last_name']); ?>

</td>

<td>

<?php echo htmlspecialchars($row['email']); ?>

</td>

<td>

<?php echo htmlspecialchars($row['contact']); ?>

</td>

<td>

<?php echo htmlspecialchars($row['address']); ?>

</td>

<td>

<?php echo date("M d, Y", strtotime($row['created_at'])); ?>

</td>

<td>

<a
href="view-customer.php?id=<?php echo $row['user_id']; ?>"
class="btn btn-info btn-sm">

<i class="bi bi-eye"></i>

</a>

<a
href="customers.php?delete=<?php echo $row['user_id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Are you sure you want to delete this customer?')">

<i class="bi bi-trash"></i>

</a>

</td>

</tr>

<?php

}

}else{

?>

<tr>

<td colspan="7" class="text-center">

No customers found.

</td>

</tr>

<?php

}

?>

</div>
</tbody>

</table>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>