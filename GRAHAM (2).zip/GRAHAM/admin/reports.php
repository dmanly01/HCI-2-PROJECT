<?php
include '../config/database.php';

/* ==========================
   TOTAL SALES (Delivered Orders Only)
========================== */

$totalSalesQuery = $conn->query("
SELECT IFNULL(SUM(total_amount),0) AS totalSales
FROM orders
WHERE status='Delivered'
");

$totalSales = $totalSalesQuery->fetch_assoc()['totalSales'];

/* ==========================
   TOTAL ORDERS
========================== */

$totalOrdersQuery = $conn->query("
SELECT COUNT(*) AS totalOrders
FROM orders
");

$totalOrders = $totalOrdersQuery->fetch_assoc()['totalOrders'];

/* ==========================
   TOTAL CUSTOMERS
========================== */

$totalCustomersQuery = $conn->query("
SELECT COUNT(*) AS totalCustomers
FROM users
WHERE role='Customer'
");

$totalCustomers = $totalCustomersQuery->fetch_assoc()['totalCustomers'];

/* ==========================
   BEST SELLING PRODUCT
========================== */

$bestSellingQuery = $conn->query("
SELECT
    products.product_name,
    SUM(order_items.quantity) AS totalSold

FROM order_items

INNER JOIN products
ON products.product_id = order_items.product_id

GROUP BY products.product_id

ORDER BY totalSold DESC

LIMIT 1
");

$bestSelling = $bestSellingQuery->fetch_assoc();

/* ==========================
   SALES REPORT TABLE
========================== */

$reportQuery = $conn->query("
SELECT
    orders.order_id,
    CONCAT(users.first_name,' ',users.last_name) AS customer,
    orders.order_date,
    orders.total_amount,
    orders.status,
    payments.payment_method

FROM orders

INNER JOIN users
ON orders.user_id = users.user_id

LEFT JOIN payments
ON orders.order_id = payments.order_id

ORDER BY orders.order_date DESC
");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Reports | Graham Delight Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#f5f5f5;
}

.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:250px;
    height:100vh;
    background:#6F4E37;
}

.sidebar h3{
    color:white;
    text-align:center;
    padding:20px;
    font-weight:bold;
}

.sidebar a{
    display:block;
    padding:15px 25px;
    color:white;
    text-decoration:none;
    transition:.3s;
}

.sidebar a:hover,
.sidebar a.active{
    background:#D4AF37;
}

.main{
    margin-left:250px;
    padding:30px;
}

.card{
    border:none;
    border-radius:15px;
}

.stat-card{
    color:white;
    border-radius:15px;
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

<h3>🍰 Graham Delight</h3>

<a href="dashboard.php">
<i class="bi bi-speedometer2"></i>
Dashboard
</a>

<a href="products.php">
<i class="bi bi-box-seam"></i>
Products
</a>

<a href="orders.php">
<i class="bi bi-cart-check"></i>
Orders
</a>

<a href="customers.php">
<i class="bi bi-people"></i>
Customers
</a>

<a href="inventory.php">
<i class="bi bi-boxes"></i>
Inventory
</a>

<a href="reports.php" class="active">
<i class="bi bi-bar-chart"></i>
Reports
</a>

<a href="../logout.php">
<i class="bi bi-box-arrow-right"></i>
Logout
</a>

</div>

<!-- MAIN -->

<div class="main">

<h2 class="mb-4">

Sales Reports

</h2>

<div class="row">

<div class="col-md-3">

<div class="card stat-card bg-success shadow">

<div class="card-body">

<h6>Total Sales</h6>

<h3>

₱<?php echo number_format($totalSales,2); ?>

</h3>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card stat-card bg-primary shadow">

<div class="card-body">

<h6>Total Orders</h6>

<h3>

<?php echo $totalOrders; ?>

</h3>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card stat-card bg-warning shadow">

<div class="card-body">

<h6>Total Customers</h6>

<h3>

<?php echo $totalCustomers; ?>

</h3>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card stat-card bg-danger shadow">

<div class="card-body">

<h6>Best Seller</h6>

<h6>

<?php

echo $bestSelling
? htmlspecialchars($bestSelling['product_name'])
: "No Data";

?>

</h6>

<p>

Sold:

<?php

echo $bestSelling
? $bestSelling['totalSold']
: 0;

?>

</p>

</div>

</div>

</div>

</div>

<br>

<div class="card shadow">

<div class="card-header bg-dark text-white">

Sales Report

</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-hover">

<thead class="table-dark">

<tr>

<th>Order ID</th>
<th>Customer</th>
<th>Date</th>
<th>Payment</th>
<th>Total</th>
<th>Status</th>

</tr>

</thead>

<tbody>

<?php

if($reportQuery->num_rows > 0){

while($row = $reportQuery->fetch_assoc()){

?>

<tr>

<td>

#<?php echo $row['order_id']; ?>

</td>

<td>

<?php echo htmlspecialchars($row['customer']); ?>

</td>

<td>

<?php echo date("M d, Y", strtotime($row['order_date'])); ?>

</td>

<td>

<?php echo htmlspecialchars($row['payment_method'] ?? 'N/A'); ?>

</td>

<td>

₱<?php echo number_format($row['total_amount'],2); ?>

</td>

<td>

<?php

if($row['status']=="Pending"){

    echo '<span class="badge bg-secondary">Pending</span>';

}elseif($row['status']=="Preparing"){

    echo '<span class="badge bg-warning text-dark">Preparing</span>';

}elseif($row['status']=="Out for Delivery"){

    echo '<span class="badge bg-primary">Out for Delivery</span>';

}elseif($row['status']=="Delivered"){

    echo '<span class="badge bg-success">Delivered</span>';

}else{

    echo '<span class="badge bg-danger">Cancelled</span>';

}

?>

</td>

</tr>

<?php

}

}else{

?>

<tr>

<td colspan="6" class="text-center">

No sales records found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

<hr>

<div class="d-flex justify-content-end">

<button
onclick="window.print()"
class="btn btn-primary">

<i class="bi bi-printer"></i>

Print Report

</button>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>