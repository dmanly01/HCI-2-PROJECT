<?php
include '../config/database.php';

if(!isset($_GET['id'])){

    header("Location: customers.php");
    exit();

}

$user_id = (int)$_GET['id'];

/* ==========================
   CUSTOMER INFORMATION
========================== */

$stmt = $conn->prepare("
SELECT *
FROM users
WHERE user_id=?
");

$stmt->bind_param("i",$user_id);
$stmt->execute();

$result = $stmt->get_result();

if($result->num_rows==0){

    die("Customer not found.");

}

$customer = $result->fetch_assoc();

/* ==========================
   CUSTOMER ORDERS
========================== */

$orderQuery = $conn->prepare("
SELECT
    orders.order_id,
    orders.total_amount,
    orders.status,
    orders.order_date,
    payments.payment_method
FROM orders

LEFT JOIN payments
ON orders.order_id = payments.order_id

WHERE orders.user_id=?

ORDER BY orders.order_date DESC
");

$orderQuery->bind_param("i",$user_id);
$orderQuery->execute();

$orders = $orderQuery->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>View Customer | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#f5f5f5;
}

.container{
    max-width:1100px;
    margin:40px auto;
}

.card{
    border:none;
    border-radius:15px;
}

.table th,
.table td{
    vertical-align:middle;
}

</style>

</head>

<body>

<div class="container">

<div class="card shadow">

<div class="card-header bg-dark text-white">

<h3 class="mb-0">

<i class="bi bi-person-circle"></i>

Customer Details

</h3>

</div>

<div class="card-body">

<div class="row">

<div class="col-md-6">

<h5 class="mb-3">

Personal Information

</h5>

<p><strong>Customer ID:</strong>

<?php echo $customer['user_id']; ?>

</p>

<p><strong>Full Name:</strong>

<?php echo htmlspecialchars($customer['first_name']." ".$customer['last_name']); ?>

</p>

<p><strong>Email:</strong>

<?php echo htmlspecialchars($customer['email']); ?>

</p>

<p><strong>Contact:</strong>

<?php echo htmlspecialchars($customer['contact']); ?>

</p>

<p><strong>Address:</strong>

<?php echo htmlspecialchars($customer['address']); ?>

</p>

<p><strong>Registered:</strong>

<?php echo date("F d, Y", strtotime($customer['created_at'])); ?>

</p>

</div>

<div class="col-md-6">

<div class="alert alert-info">

<h5>Total Orders</h5>

<h2>

<?php echo $orders->num_rows; ?>

</h2>

</div>

</div>

</div>

<hr>

<h4 class="mb-3">

Order History

</h4>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>Order ID</th>
<th>Date</th>
<th>Payment</th>
<th>Total</th>
<th>Status</th>

</tr>

</thead>

<tbody>

<?php

if($orders->num_rows > 0){

while($row = $orders->fetch_assoc()){

?>

<tr>

<td>

#<?php echo $row['order_id']; ?>

</td>

<td>

<?php echo date("M d, Y", strtotime($row['order_date'])); ?>

</td>

<td>

<?php echo htmlspecialchars($row['payment_method'] ?? 'N/A'); ?>

</td>

<td>

₱<?php echo number_format($row['total_amount'],2); ?>

</td>

<td>

<?php

$status = $row['status'];

if($status=="Pending"){

    echo '<span class="badge bg-secondary">Pending</span>';

}elseif($status=="Preparing"){

    echo '<span class="badge bg-warning text-dark">Preparing</span>';

}elseif($status=="Out for Delivery"){

    echo '<span class="badge bg-primary">Out for Delivery</span>';

}elseif($status=="Delivered"){

    echo '<span class="badge bg-success">Delivered</span>';

}else{

    echo '<span class="badge bg-danger">Cancelled</span>';

}

?>

</td>

</tr>

<?php

}

}else{

?>

<tr>

<td colspan="5" class="text-center">

No orders found for this customer.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

<hr>

<div class="d-flex justify-content-between">

<a
href="customers.php"
class="btn btn-secondary">

<i class="bi bi-arrow-left"></i>

Back to Customers

</a>

<button
onclick="window.print()"
class="btn btn-primary">

<i class="bi bi-printer"></i>

Print Customer Details

</button>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>