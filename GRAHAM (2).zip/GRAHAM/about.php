<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>About Us | Graham Delight</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
rel="stylesheet">

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#FFF8F0;
    color:#4b3621;
}

/* NAVBAR */

.navbar{
    background:#6F4E37;
}

.navbar-brand{
    font-weight:700;
}

.nav-link{
    color:white !important;
}

.nav-link:hover,
.nav-link.active{
    color:#D4AF37 !important;
}

/* HERO */

.about-hero{
    background:linear-gradient(
        rgba(111,78,55,.88),
        rgba(111,78,55,.88)
    ),
    url("assets/images/hero.jpg");

    background-size:cover;
    background-position:center;

    color:white;
    padding:100px 20px;
    text-align:center;
}

.about-hero h1{
    font-size:50px;
    font-weight:700;
}

.about-hero p{
    font-size:18px;
}

/* SECTION */

.section-title{
    color:#6F4E37;
    font-weight:700;
}

/* STORY */

.story-card{
    background:white;
    border:none;
    border-radius:20px;
    padding:35px;
    box-shadow:0 8px 25px rgba(0,0,0,.08);
}

/* FEATURES */

.feature-card{
    background:white;
    border:none;
    border-radius:18px;
    padding:30px 20px;
    text-align:center;
    height:100%;
    box-shadow:0 8px 20px rgba(0,0,0,.08);
    transition:.3s;
}

.feature-card:hover{
    transform:translateY(-8px);
}

.feature-icon{
    font-size:45px;
    margin-bottom:15px;
}

/* MISSION */

.mission-card{
    background:#6F4E37;
    color:white;
    border-radius:20px;
    padding:40px;
    height:100%;
}

.vision-card{
    background:#D4AF37;
    color:white;
    border-radius:20px;
    padding:40px;
    height:100%;
}

/* CTA */

.cta{
    background:#f3e4d3;
    padding:70px 20px;
    text-align:center;
}

.btn-order{
    background:#6F4E37;
    color:white;
    border:none;
    padding:12px 30px;
    border-radius:30px;
    font-weight:600;
}

.btn-order:hover{
    background:#55351f;
    color:white;
}

/* FOOTER */

footer{
    background:#6F4E37;
    color:white;
}

</style>

</head>

<body>


<!-- NAVBAR -->

<nav class="navbar navbar-expand-lg navbar-dark shadow">

<div class="container">

<a
class="navbar-brand"
href="index.php">

🍰 Graham Delight

</a>

<button
class="navbar-toggler"
type="button"
data-bs-toggle="collapse"
data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div
class="collapse navbar-collapse"
id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">

<a
class="nav-link"
href="index.php">

Home

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="product.php">

Products

</a>

</li>

<li class="nav-item">

<a
class="nav-link active"
href="about.php">

About

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="contact.php">

Contact

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="login.php">

Login

</a>

</li>

</ul>

</div>

</div>

</nav>


<!-- HERO -->

<section class="about-hero">

<div class="container">

<h1>About Graham Delight</h1>

<p class="mt-3 mb-0">

Delicious homemade graham desserts made with love.

</p>

</div>

</section>


<!-- OUR STORY -->

<section class="py-5">

<div class="container">

<div class="row justify-content-center">

<div class="col-lg-9">

<div class="story-card">

<h2 class="section-title mb-4 text-center">

Our Story

</h2>

<p>

<strong>Graham Delight</strong> is a homemade dessert business
focused on creating delicious, creamy, and satisfying graham
desserts that customers can enjoy for any occasion.

</p>

<p>

Our desserts are carefully prepared using quality ingredients
and creative flavor combinations. From the tropical taste of
<strong>Pineapplemisu</strong> to the classic sweetness of
<strong>Mango Graham</strong> and the rich flavor of
<strong>Tiramisu Graham</strong>, every dessert is made to give
customers a delightful experience.

</p>

<p class="mb-0">

We believe that a simple dessert can create a memorable moment.
That's why every Graham Delight product is prepared with care,
freshness, and love.

</p>

</div>

</div>

</div>

</div>

</section>


<!-- WHY CHOOSE US -->

<section class="py-5 bg-light">

<div class="container">

<div class="text-center mb-5">

<h2 class="section-title">

Why Choose Graham Delight?

</h2>

<p class="text-muted">

We put quality and customer satisfaction first.

</p>

</div>

<div class="row g-4">


<div class="col-md-3">

<div class="feature-card">

<div class="feature-icon">
🍍
</div>

<h5 class="fw-bold">
Fresh Ingredients
</h5>

<p class="text-muted">
We use quality ingredients to create delicious desserts.
</p>

</div>

</div>


<div class="col-md-3">

<div class="feature-card">

<div class="feature-icon">
🥛
</div>

<h5 class="fw-bold">
Creamy & Delicious
</h5>

<p class="text-muted">
Our desserts are made with rich and creamy layers.
</p>

</div>

</div>


<div class="col-md-3">

<div class="feature-card">

<div class="feature-icon">
❤️
</div>

<h5 class="fw-bold">
Made with Love
</h5>

<p class="text-muted">
Every dessert is prepared carefully for our customers.
</p>

</div>

</div>


<div class="col-md-3">

<div class="feature-card">

<div class="feature-icon">
✨
</div>

<h5 class="fw-bold">
Quality Service
</h5>

<p class="text-muted">
We aim to provide a pleasant ordering experience.
</p>

</div>

</div>


</div>

</div>

</section>


<!-- MISSION AND VISION -->

<section class="py-5">

<div class="container">

<div class="row g-4">


<div class="col-md-6">

<div class="mission-card">

<h2 class="fw-bold mb-3">

Our Mission

</h2>

<p class="mb-0">

To provide delicious, high-quality homemade graham desserts
that bring joy and satisfaction to every customer while
maintaining excellent service and care in every order.

</p>

</div>

</div>


<div class="col-md-6">

<div class="vision-card">

<h2 class="fw-bold mb-3">

Our Vision

</h2>

<p class="mb-0">

To become a trusted homemade dessert brand known for
creative flavors, quality ingredients, delicious products,
and excellent customer experience.

</p>

</div>

</div>


</div>

</div>

</section>


<!-- PRODUCTS -->

<section class="py-5 bg-light">

<div class="container">

<div class="text-center mb-5">

<h2 class="section-title">

Our Signature Desserts

</h2>

<p class="text-muted">

Discover some of our favorite Graham Delight flavors.

</p>

</div>

<div class="row g-4">


<div class="col-md-4">

<div class="feature-card">

<h2>🍍</h2>

<h4 class="fw-bold">
Pineapplemisu
</h4>

<p class="text-muted">

A tropical twist on tiramisu with a refreshing pineapple flavor.

</p>

</div>

</div>


<div class="col-md-4">

<div class="feature-card">

<h2>🥭</h2>

<h4 class="fw-bold">
Mango Graham
</h4>

<p class="text-muted">

Fresh mango combined with creamy filling and graham layers.

</p>

</div>

</div>


<div class="col-md-4">

<div class="feature-card">

<h2>🍫</h2>

<h4 class="fw-bold">
Choco Graham
</h4>

<p class="text-muted">

A rich chocolate dessert perfect for chocolate lovers.

</p>

</div>

</div>


</div>

</div>

</section>


<!-- CTA -->

<section class="cta">

<div class="container">

<h2
class="section-title mb-3">

Ready for a Sweet Treat?

</h2>

<p class="text-muted mb-4">

Explore our delicious homemade graham desserts today.

</p>

<a
href="product.php"
class="btn btn-order">

<i class="bi bi-shop"></i>

View Our Products

</a>

</div>

</section>


<!-- FOOTER -->

<footer class="pt-5 pb-3">

<div class="container">

<div class="row">


<div class="col-lg-5">

<h4 class="fw-bold">
🍰 Graham Delight
</h4>

<p>

Delicious homemade graham desserts made with quality
ingredients and lots of love.

</p>

</div>


<div class="col-lg-3">

<h5>
Quick Links
</h5>

<p class="mb-1">

<a
href="index.php"
class="text-white text-decoration-none">

Home

</a>

</p>

<p class="mb-1">

<a
href="product.php"
class="text-white text-decoration-none">

Products

</a>

</p>

<p class="mb-1">

<a
href="about.php"
class="text-white text-decoration-none">

About

</a>

</p>

</div>


<div class="col-lg-4">

<h5>
Contact
</h5>

<p class="mb-1">
📍 Legazpi City, Albay
</p>

<p class="mb-1">
📞 +63 912 345 6789
</p>

<p>
📧 grahamdelight@email.com
</p>

</div>


</div>

<hr class="border-light">

<p class="text-center mb-0">

© 2026 Graham Delight. All Rights Reserved.

</p>

</div>

</footer>


<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>

</html>