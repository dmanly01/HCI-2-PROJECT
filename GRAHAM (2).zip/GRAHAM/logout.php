<?php

session_start();

/*
Clear all session variables
*/
$_SESSION = array();

/*
Destroy the session
*/
session_destroy();

/*
Return to the single login page
*/
header("Location: login.php");
exit();

?>