<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Contact Us | Graham Delight</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
rel="stylesheet">

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#FFF8F0;
    color:#4b3621;
}

.navbar{
    background:#6F4E37;
}

.navbar-brand{
    font-weight:700;
}

.nav-link{
    color:white !important;
}

.nav-link:hover,
.nav-link.active{
    color:#D4AF37 !important;
}

/* HERO */

.contact-hero{
    background:#6F4E37;
    color:white;
    padding:80px 20px;
    text-align:center;
}

.contact-hero h1{
    font-size:48px;
    font-weight:700;
}

.contact-hero p{
    font-size:18px;
}

/* CONTACT CARDS */

.contact-card{
    background:white;
    border:none;
    border-radius:18px;
    padding:30px 20px;
    text-align:center;
    height:100%;
    box-shadow:0 8px 20px rgba(0,0,0,.08);
    transition:.3s;
}

.contact-card:hover{
    transform:translateY(-7px);
}

.contact-icon{
    width:65px;
    height:65px;
    background:#D4AF37;
    color:white;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    margin:0 auto 15px;
    font-size:28px;
}

/* FORM */

.form-card{
    background:white;
    border:none;
    border-radius:20px;
    box-shadow:0 8px 25px rgba(0,0,0,.08);
}

.form-control{
    border-radius:10px;
    padding:12px;
}

.form-control:focus{
    border-color:#D4AF37;
    box-shadow:0 0 0 .2rem rgba(212,175,55,.2);
}

.btn-send{
    background:#6F4E37;
    color:white;
    border:none;
    border-radius:30px;
    padding:12px 30px;
    font-weight:600;
}

.btn-send:hover{
    background:#55351f;
    color:white;
}

/* CTA */

.cta{
    background:#f3e4d3;
    padding:60px 20px;
    text-align:center;
}

.btn-order{
    background:#D4AF37;
    color:white;
    border:none;
    border-radius:30px;
    padding:12px 30px;
    font-weight:600;
}

.btn-order:hover{
    background:#b89328;
    color:white;
}

/* FOOTER */

footer{
    background:#6F4E37;
    color:white;
}

</style>

</head>

<body>


<!-- NAVBAR -->

<nav class="navbar navbar-expand-lg navbar-dark shadow">

<div class="container">

<a
class="navbar-brand"
href="index.php">

🍰 Graham Delight

</a>

<button
class="navbar-toggler"
type="button"
data-bs-toggle="collapse"
data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div
class="collapse navbar-collapse"
id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">

<a
class="nav-link"
href="index.php">

Home

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="product.php">

Products

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="about.php">

About

</a>

</li>

<li class="nav-item">

<a
class="nav-link active"
href="contact.php">

Contact

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="login.php">

Login

</a>

</li>

</ul>

</div>

</div>

</nav>


<!-- HERO -->

<section class="contact-hero">

<div class="container">

<h1>Contact Us</h1>

<p class="mt-3 mb-0">

We'd love to hear from you! Have a question or want to place an order?

</p>

</div>

</section>


<!-- CONTACT INFORMATION -->

<section class="py-5">

<div class="container">

<div class="text-center mb-5">

<h2
style="color:#6F4E37;"
class="fw-bold">

Get In Touch

</h2>

<p class="text-muted">

You can reach Graham Delight through any of the following.

</p>

</div>


<div class="row g-4">


<!-- LOCATION -->

<div class="col-md-4">

<div class="contact-card">

<div class="contact-icon">

<i class="bi bi-geo-alt-fill"></i>

</div>

<h5 class="fw-bold">
Our Location
</h5>

<p class="text-muted mb-0">

Legazpi City, Albay

</p>

</div>

</div>


<!-- PHONE -->

<div class="col-md-4">

<div class="contact-card">

<div class="contact-icon">

<i class="bi bi-telephone-fill"></i>

</div>

<h5 class="fw-bold">
Call Us
</h5>

<p class="text-muted mb-0">

+63 912 345 6789

</p>

</div>

</div>


<!-- EMAIL -->

<div class="col-md-4">

<div class="contact-card">

<div class="contact-icon">

<i class="bi bi-envelope-fill"></i>

</div>

<h5 class="fw-bold">
Email Us
</h5>

<p class="text-muted mb-0">

grahamdelight@email.com

</p>

</div>

</div>


</div>

</div>

</section>


<!-- CONTACT FORM -->

<section class="pb-5">

<div class="container">

<div class="row justify-content-center">

<div class="col-lg-8">

<div class="card form-card">

<div class="card-body p-4 p-md-5">

<div class="text-center mb-4">

<h3
style="color:#6F4E37;"
class="fw-bold">

Send Us a Message

</h3>

<p class="text-muted">

Have a question? Send us a message and we'll be happy to help.

</p>

</div>


<form
method="POST"
action="contact.php">


<div class="row">


<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Full Name

</label>

<input
type="text"
name="name"
class="form-control"
placeholder="Enter your full name"
required>

</div>


<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Email Address

</label>

<input
type="email"
name="email"
class="form-control"
placeholder="Enter your email"
required>

</div>


<div class="col-12 mb-3">

<label class="form-label fw-semibold">

Subject

</label>

<input
type="text"
name="subject"
class="form-control"
placeholder="What is your message about?"
required>

</div>


<div class="col-12 mb-3">

<label class="form-label fw-semibold">

Message

</label>

<textarea
name="message"
class="form-control"
rows="6"
placeholder="Write your message here..."
required></textarea>

</div>


<div class="col-12 text-center">

<button
type="submit"
name="send_message"
class="btn btn-send">

<i class="bi bi-send-fill"></i>

Send Message

</button>

</div>


</div>

</form>

</div>

</div>

</div>

</div>

</div>

</section>


<!-- BUSINESS HOURS -->

<section class="py-5 bg-light">

<div class="container">

<div class="row justify-content-center">

<div class="col-lg-7">

<div class="text-center">

<h3
style="color:#6F4E37;"
class="fw-bold mb-4">

Business Hours

</h3>

<div class="bg-white rounded-4 shadow-sm p-4">

<div class="d-flex justify-content-between border-bottom py-3">

<span>Monday - Friday</span>

<strong>9:00 AM - 8:00 PM</strong>

</div>

<div class="d-flex justify-content-between border-bottom py-3">

<span>Saturday</span>

<strong>9:00 AM - 8:00 PM</strong>

</div>

<div class="d-flex justify-content-between py-3">

<span>Sunday</span>

<strong>9:00 AM - 8:00 PM</strong>

</div>

</div>

</div>

</div>

</div>

</div>

</section>


<!-- CTA -->

<section class="cta">

<div class="container">

<h2
style="color:#6F4E37;"
class="fw-bold">

Ready for Something Sweet?

</h2>

<p class="text-muted mb-4">

Check out our delicious homemade graham desserts.

</p>

<a
href="product.php"
class="btn btn-order">

<i class="bi bi-shop"></i>

View Products

</a>

</div>

</section>


<!-- FOOTER -->

<footer class="pt-5 pb-3">

<div class="container">

<div class="row">


<div class="col-lg-5">

<h4 class="fw-bold">

🍰 Graham Delight

</h4>

<p>

Delicious homemade graham desserts made with quality
ingredients and lots of love.

</p>

</div>


<div class="col-lg-3">

<h5>Quick Links</h5>

<p class="mb-1">

<a
href="index.php"
class="text-white text-decoration-none">

Home

</a>

</p>

<p class="mb-1">

<a
href="product.php"
class="text-white text-decoration-none">

Products

</a>

</p>

<p class="mb-1">

<a
href="about.php"
class="text-white text-decoration-none">

About

</a>

</p>

<p class="mb-1">

<a
href="contact.php"
class="text-white text-decoration-none">

Contact

</a>

</p>

</div>


<div class="col-lg-4">

<h5>Contact</h5>

<p class="mb-1">
📍 Legazpi City, Albay
</p>

<p class="mb-1">
📞 +63 912 345 6789
</p>

<p>
📧 grahamdelight@email.com
</p>

</div>


</div>

<hr class="border-light">

<p class="text-center mb-0">

© 2026 Graham Delight. All Rights Reserved.

</p>

</div>

</footer>


<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>

</html>