<?php
session_start();
include '../config/database.php';

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "
SELECT *
FROM orders
WHERE user_id=?
ORDER BY order_date DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$user_id);
$stmt->execute();

$result = $stmt->get_result();
?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>My Orders</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>

body{
background:#FFF8F0;
font-family:Poppins,sans-serif;
}

.card{
border:none;
border-radius:15px;
}

</style>

</head>

<body>

<div class="container py-5">

<h2 class="mb-4">

📦 My Orders

</h2>
<?php if($result->num_rows > 0){ ?>

<div class="card shadow">

<div class="card-body">

<div class="table-responsive">

<table class="table table-hover align-middle">

<thead class="table-dark">

<tr>

<th>Order ID</th>

<th>Date</th>

<th>Total</th>

<th>Payment</th>

<th>Status</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td>

#<?php echo $row['order_id']; ?>

</td>

<td>

<?php echo date("M d, Y h:i A", strtotime($row['order_date'])); ?>

</td>

<td>

<strong>

₱<?php echo number_format($row['total_amount'],2); ?>

</strong>

</td>

<td>

<?php echo htmlspecialchars($row['payment_method']); ?>

</td>

<td>

<?php

$status = strtolower($row['status']);

if($status=="pending"){

echo "<span class='badge bg-warning text-dark'>Pending</span>";

}elseif($status=="preparing"){

echo "<span class='badge bg-info'>Preparing</span>";

}elseif($status=="completed"){

echo "<span class='badge bg-success'>Completed</span>";

}elseif($status=="cancelled"){

echo "<span class='badge bg-danger'>Cancelled</span>";

}else{

echo "<span class='badge bg-secondary'>".$row['status']."</span>";

}

?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<?php } else { ?>

<div class="card shadow">

<div class="card-body text-center p-5">

<i class="bi bi-bag-x" style="font-size:70px;color:#999;"></i>

<h3 class="mt-3">

No Orders Yet

</h3>

<p class="text-muted">

You haven't placed any orders yet.

</p>

<a href="product.php" class="btn btn-primary">

<i class="bi bi-bag"></i>

Shop Now

</a>

</div>

</div>

<?php } ?>

<div class="mt-4">

<a href="product.php" class="btn btn-secondary">

<i class="bi bi-arrow-left"></i>

Back to Products

</a>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>