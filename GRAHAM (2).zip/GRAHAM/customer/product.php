<?php
session_start();
include '../config/database.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$search = "";

$sql = "SELECT p.*, c.category_name, i.stock
        FROM products p
        LEFT JOIN categories c ON p.category_id=c.category_id
        LEFT JOIN inventory i ON p.product_id=i.product_id
        WHERE p.status='Available'";

if(isset($_GET['search']) && $_GET['search']!=""){
    $search = trim($_GET['search']);
    $search_safe = $conn->real_escape_string($search);

    $sql .= " AND (
        p.product_name LIKE '%$search_safe%'
        OR c.category_name LIKE '%$search_safe%'
    )";
}

$sql .= " ORDER BY p.product_id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Products | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

body{
background:#FFF8F0;
font-family:Poppins,sans-serif;
}

.navbar{
background:#6F4E37;
}

.navbar-brand{
color:white;
font-weight:700;
}

.nav-link{
color:white!important;
}

.card{
border:none;
border-radius:15px;
transition:.3s;
}

.card:hover{
transform:translateY(-5px);
box-shadow:0 10px 25px rgba(0,0,0,.15);
}

.card img{
height:230px;
object-fit:cover;
}

.price{
font-size:22px;
font-weight:bold;
color:#D4AF37;
}

.stock{
font-size:14px;
}

.btn-cart{
background:#6F4E37;
color:white;
}

.btn-cart:hover{
background:#55351f;
color:white;
}

</style>

</head>

<body>

<nav class="navbar navbar-expand-lg">

<div class="container">

<a class="navbar-brand" href="#">
🍰 Graham Delight
</a>

<div class="ms-auto">

<a href="cart.php" class="btn btn-warning">

<i class="bi bi-cart-fill"></i>

Cart

</a>

<a href="dashboard.php" class="btn btn-light">

Dashboard

</a>

<a href="logout.php" class="btn btn-danger">

Logout

</a>

</div>

</div>

</nav>

<div class="container py-5">

<form method="GET">

<div class="row mb-4">

<div class="col-md-10">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Products..."
value="<?php echo htmlspecialchars($search); ?>">

</div>

<div class="col-md-2">

<button class="btn btn-dark w-100">

Search

</button>

</div>

</div>

</form>

<div class="row">

<?php

if($result->num_rows > 0){

while($row = $result->fetch_assoc()){

$image = "../uploads/products/".$row['image'];

if(!file_exists($image) || empty($row['image'])){
    $image="../assets/images/image.png";
}
?>

<div class="col-lg-4 col-md-6 mb-4">

<div class="card h-100 shadow-sm">

<img src="<?php echo $image; ?>" class="card-img-top">

<div class="card-body d-flex flex-column">

<h5>

<?php echo htmlspecialchars($row['product_name']); ?>

</h5>

<p class="text-muted">

<?php echo htmlspecialchars($row['description']); ?>

</p>

<div class="mb-2">

<span class="badge bg-secondary">

<?php echo htmlspecialchars($row['category_name']); ?>

</span>

</div>

<div class="price mb-2">

₱<?php echo number_format($row['price'],2); ?>

</div>

<?php

if($row['stock']>0){

echo "<span class='badge bg-success mb-3'>In Stock (".$row['stock'].")</span>";

}else{

echo "<span class='badge bg-danger mb-3'>Out of Stock</span>";

}

?>

<div class="mt-auto">

<?php

if($row['stock']>0){

?>

<a href="add-to-cart.php?product_id=<?php echo $row['product_id']; ?>"

class="btn btn-cart w-100">

<i class="bi bi-cart-plus"></i>

Add to Cart

</a>

<?php

}else{

?>

<button class="btn btn-secondary w-100" disabled>

Out of Stock

</button>

<?php

}

?>

</div>

</div>

</div>

</div>

<?php

}

}else{

?>

<div class="col-12">

<div class="alert alert-warning">

No Products Found.

</div>

</div>

<?php

}

?>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>