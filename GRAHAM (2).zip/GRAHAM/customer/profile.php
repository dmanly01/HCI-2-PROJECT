<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

/* ==========================
   UPDATE PROFILE
========================== */

if (isset($_POST['update_profile'])) {

    $first_name = trim($_POST['first_name']);
    $last_name  = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $contact    = trim($_POST['contact']);
    $address    = trim($_POST['address']);

    if ($first_name == "" || $last_name == "" || $email == "") {

        $message = '<div class="alert alert-danger">
            First Name, Last Name, and Email are required.
        </div>';

    } else {

        /* Check if email is already used by another account */
        $check = $conn->prepare("
            SELECT user_id
            FROM users
            WHERE email = ?
            AND user_id != ?
        ");

        $check->bind_param("si", $email, $user_id);
        $check->execute();

        $checkResult = $check->get_result();

        if ($checkResult->num_rows > 0) {

            $message = '<div class="alert alert-danger">
                This email is already being used by another account.
            </div>';

        } else {

            $update = $conn->prepare("
                UPDATE users
                SET first_name = ?,
                    last_name = ?,
                    email = ?,
                    contact = ?,
                    address = ?
                WHERE user_id = ?
            ");

            $update->bind_param(
                "sssssi",
                $first_name,
                $last_name,
                $email,
                $contact,
                $address,
                $user_id
            );

            if ($update->execute()) {

                $message = '<div class="alert alert-success">
                    <i class="bi bi-check-circle-fill"></i>
                    Profile updated successfully!
                </div>';

            } else {

                $message = '<div class="alert alert-danger">
                    Failed to update profile.
                </div>';
            }
        }
    }
}


/* ==========================
   GET CUSTOMER INFORMATION
========================== */

$stmt = $conn->prepare("
    SELECT
        user_id,
        first_name,
        last_name,
        email,
        contact,
        address
    FROM users
    WHERE user_id = ?
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    session_destroy();
    header("Location: ../login.php");
    exit();
}

$user = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Profile | Graham Delight</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
rel="stylesheet">

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

<style>

*{
    font-family:'Poppins',sans-serif;
}

body{
    background:#FFF8F0;
}

.navbar{
    background:#6F4E37;
}

.navbar-brand{
    color:white;
    font-weight:700;
}

.nav-link{
    color:white !important;
}

.profile-card{
    border:none;
    border-radius:20px;
    overflow:hidden;
}

.profile-header{
    background:#6F4E37;
    color:white;
    padding:30px;
    text-align:center;
}

.profile-icon{
    width:90px;
    height:90px;
    background:#D4AF37;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    margin:0 auto 15px;
    font-size:42px;
    color:white;
}

.btn-save{
    background:#6F4E37;
    color:white;
    border:none;
}

.btn-save:hover{
    background:#55351f;
    color:white;
}

.form-label{
    font-weight:500;
    color:#5C4033;
}

</style>

</head>

<body>


<!-- NAVBAR -->

<nav class="navbar navbar-expand-lg">

<div class="container">

<a
class="navbar-brand"
href="dashboard.php">

🍰 Graham Delight

</a>

<div class="ms-auto">

<a
href="dashboard.php"
class="btn btn-light btn-sm me-2">

<i class="bi bi-speedometer2"></i>
Dashboard

</a>

<a
href="product.php"
class="btn btn-warning btn-sm me-2">

<i class="bi bi-shop"></i>
Products

</a>

<a
href="cart.php"
class="btn btn-warning btn-sm me-2">

<i class="bi bi-cart-fill"></i>
Cart

</a>

<a
href="../logout.php"
class="btn btn-danger btn-sm">

<i class="bi bi-box-arrow-right"></i>
Logout

</a>

</div>

</div>

</nav>


<!-- PROFILE -->

<div class="container py-5">

<div class="row justify-content-center">

<div class="col-lg-8">

<div class="card profile-card shadow">

<div class="profile-header">

<div class="profile-icon">

<i class="bi bi-person-fill"></i>

</div>

<h3 class="mb-1">

<?php
echo htmlspecialchars(
    $user['first_name'] . ' ' . $user['last_name']
);
?>

</h3>

<p class="mb-0">
My Customer Profile
</p>

</div>


<div class="card-body p-4">

<?php echo $message; ?>

<form method="POST">

<div class="row">

<!-- FIRST NAME -->

<div class="col-md-6 mb-3">

<label class="form-label">
First Name
</label>

<input
type="text"
name="first_name"
class="form-control"
value="<?php echo htmlspecialchars($user['first_name']); ?>"
required>

</div>


<!-- LAST NAME -->

<div class="col-md-6 mb-3">

<label class="form-label">
Last Name
</label>

<input
type="text"
name="last_name"
class="form-control"
value="<?php echo htmlspecialchars($user['last_name']); ?>"
required>

</div>


<!-- EMAIL -->

<div class="col-md-6 mb-3">

<label class="form-label">
Email
</label>

<input
type="email"
name="email"
class="form-control"
value="<?php echo htmlspecialchars($user['email']); ?>"
required>

</div>


<!-- CONTACT -->

<div class="col-md-6 mb-3">

<label class="form-label">
Contact Number
</label>

<input
type="text"
name="contact"
class="form-control"
value="<?php echo htmlspecialchars($user['contact']); ?>">

</div>


<!-- ADDRESS -->

<div class="col-12 mb-4">

<label class="form-label">
Address
</label>

<textarea
name="address"
class="form-control"
rows="3"><?php echo htmlspecialchars($user['address']); ?></textarea>

</div>


<!-- BUTTON -->

<div class="col-12">

<button
type="submit"
name="update_profile"
class="btn btn-save w-100">

<i class="bi bi-save"></i>

Save Changes

</button>

</div>

</div>

</form>

</div>

</div>

</div>

</div>

</div>


<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>

</html>