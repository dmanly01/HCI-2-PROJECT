<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "
SELECT
    c.cart_id,
    c.quantity,
    p.product_id,
    p.product_name,
    p.price,
    p.image
FROM cart c
INNER JOIN products p
ON c.product_id = p.product_id
WHERE c.user_id=?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$user_id);
$stmt->execute();

$result = $stmt->get_result();

$grandTotal = 0;
?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Checkout</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>

body{
background:#FFF8F0;
font-family:Poppins,sans-serif;
}

.card{
border:none;
border-radius:15px;
}

</style>

</head>

<body>

<div class="container py-5">

<h2 class="mb-4">

Checkout

</h2>

<form action="place-order.php" method="POST">

<div class="row">

<div class="col-lg-8">

<div class="card shadow">

<div class="card-body">

<h4 class="mb-3">

Order Summary

</h4>
<table class="table">

<thead>

<tr>

<th>Product</th>

<th>Qty</th>

<th>Price</th>

<th>Subtotal</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()){

$subtotal = $row['price'] * $row['quantity'];

$grandTotal += $subtotal;

?>

<tr>

<td>

<?php echo htmlspecialchars($row['product_name']); ?>

</td>

<td>

<?php echo $row['quantity']; ?>

</td>

<td>

₱<?php echo number_format($row['price'],2); ?>

</td>

<td>

₱<?php echo number_format($subtotal,2); ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

<hr>

<div class="text-end">

<h3>

Total :

<strong class="text-success">

₱<?php echo number_format($grandTotal,2); ?>

</strong>

</h3>

</div>

</div>

</div>

</div>

<div class="col-lg-4">

<div class="card shadow">

<div class="card-body">

<h4 class="mb-3">

Payment Method

</h4>

<div class="form-check">

<input
class="form-check-input"
type="radio"
name="payment_method"
value="Cash on Delivery"
checked>

<label class="form-check-label">

Cash on Delivery

</label>

</div>

<div class="form-check mt-2">

<input
class="form-check-input"
type="radio"
name="payment_method"
value="GCash">

<label class="form-check-label">

GCash

</label>

</div>

<hr>

<input
type="hidden"
name="total_amount"
value="<?php echo $grandTotal; ?>">

<button
type="submit"
class="btn btn-success w-100">

<i class="bi bi-check-circle"></i>

Place Order

</button>

<a
href="cart.php"
class="btn btn-secondary w-100 mt-2">

Back to Cart

</a>

</div>

</div>

</div>

</div>

</form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>