<?php
session_start();
include '../config/database.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "
SELECT
    c.cart_id,
    c.quantity,
    p.product_id,
    p.product_name,
    p.price,
    p.image,
    IFNULL(i.stock,0) AS stock
FROM cart c
INNER JOIN products p
ON c.product_id = p.product_id
LEFT JOIN inventory i
ON p.product_id = i.product_id
WHERE c.user_id = ?
ORDER BY c.cart_id DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$user_id);
$stmt->execute();
$result = $stmt->get_result();

$grandTotal = 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Shopping Cart</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>

body{
background:#FFF8F0;
font-family:Poppins,sans-serif;
}

.navbar{
background:#6F4E37;
}

.navbar-brand{
color:white;
font-weight:bold;
}

.card{
border:none;
border-radius:15px;
}

.product-img{
width:90px;
height:90px;
object-fit:cover;
border-radius:10px;
}

.total-box{
background:#fff;
padding:20px;
border-radius:15px;
box-shadow:0 0 15px rgba(0,0,0,.08);
}

</style>

</head>

<body>

<nav class="navbar navbar-expand-lg">

<div class="container">

<a class="navbar-brand">

🍰 Graham Delight

</a>

<div>

<a href="product.php" class="btn btn-warning">

Continue Shopping

</a>

<a href="logout.php" class="btn btn-danger">

Logout

</a>

</div>

</div>

</nav>

<div class="container py-5">

<h2 class="mb-4">

🛒 My Shopping Cart

</h2>

<?php if($result->num_rows > 0){ ?>

<div class="card shadow">

<div class="card-body">

<div class="table-responsive">

<table class="table align-middle">

<thead class="table-dark">

<tr>

<th>Image</th>
<th>Product</th>
<th>Price</th>
<th>Quantity</th>
<th>Subtotal</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()){

$subtotal = $row['price'] * $row['quantity'];

$grandTotal += $subtotal;

$image = "../uploads/products/".$row['image'];

if(empty($row['image']) || !file_exists($image)){
    $image = "../assets/images/image.png";
}

?>

<tr>

<td>

<img src="<?php echo $image; ?>" class="product-img">

</td>

<td>

<strong>

<?php echo htmlspecialchars($row['product_name']); ?>

</strong>

<br>

<small class="text-muted">

Stock :

<?php echo $row['stock']; ?>

</small>

</td>

<td>

₱<?php echo number_format($row['price'],2); ?>

</td>

<td>

<?php echo $row['quantity']; ?>

</td>

<td>

<strong>

₱<?php echo number_format($subtotal,2); ?>

</strong>

</td>

<td>

<a href="remove-cart.php?id=<?php echo $row['cart_id']; ?>"

class="btn btn-danger btn-sm"

onclick="return confirm('Remove this item?')">

<i class="bi bi-trash"></i>

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

<hr>

<div class="row">

<div class="col-md-6">

<a href="product.php" class="btn btn-secondary">

<i class="bi bi-arrow-left"></i>

Continue Shopping

</a>

</div>

<div class="col-md-6 text-end">

<div class="total-box">

<h4>

Grand Total

</h4>

<h2 class="text-success">

₱<?php echo number_format($grandTotal,2); ?>

</h2>

<a href="checkout.php"

class="btn btn-success btn-lg mt-2">

<i class="bi bi-credit-card"></i>

Proceed to Checkout

</a>

</div>

</div>

</div>

</div>

</div>

<?php } else { ?>

<div class="card shadow">

<div class="card-body text-center p-5">

<i class="bi bi-cart-x"

style="font-size:80px;color:#999;"></i>

<h3 class="mt-3">

Your cart is empty

</h3>

<p class="text-muted">

Looks like you haven't added any products yet.

</p>

<a href="product.php"

class="btn btn-primary">

<i class="bi bi-bag"></i>

Browse Products

</a>

</div>

</div>

<?php } ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>