<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_GET['product_id'])) {
    header("Location: product.php");
    exit();
}

$product_id = (int)$_GET['product_id'];

// Check if product exists
$product = $conn->prepare("
SELECT product_id
FROM products
WHERE product_id = ?
");

$product->bind_param("i", $product_id);
$product->execute();

$productResult = $product->get_result();

if($productResult->num_rows == 0){
    die("Invalid Product.");
}

// Check if already in cart
$check = $conn->prepare("
SELECT cart_id, quantity
FROM cart
WHERE user_id=? AND product_id=?
");

$check->bind_param("ii",$user_id,$product_id);
$check->execute();

$result = $check->get_result();

if($result->num_rows>0){

    $cart = $result->fetch_assoc();

    $qty = $cart['quantity'] + 1;

    $update = $conn->prepare("
    UPDATE cart
    SET quantity=?
    WHERE cart_id=?
    ");

    $update->bind_param("ii",$qty,$cart['cart_id']);
    $update->execute();

}else{

    $insert = $conn->prepare("
    INSERT INTO cart(user_id,product_id,quantity)
    VALUES(?,?,1)
    ");

    $insert->bind_param("ii",$user_id,$product_id);
    $insert->execute();

}

header("Location: cart.php");
exit();