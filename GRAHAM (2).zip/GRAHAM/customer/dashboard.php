<?php
session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$user = $_SESSION['user_name'];

$bestSellerSql = "
    SELECT 
        p.product_id,
        p.product_name,
        p.price,
        p.image,
        SUM(oi.quantity) AS total_sold
    FROM order_items oi
    INNER JOIN products p 
        ON oi.product_id = p.product_id
    INNER JOIN orders o
        ON oi.order_id = o.order_id
    WHERE p.status = 'Available'
    GROUP BY p.product_id, p.product_name, p.price, p.image
    ORDER BY total_sold DESC
    LIMIT 4
";

$bestSellerResult = $conn->query($bestSellerSql);
?>


<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Customer Dashboard | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#f8f5f2;
}

.navbar{
background:#6F4E37;
}

.navbar-brand{
color:white;
font-weight:bold;
font-size:24px;
}

.navbar-brand:hover{
color:white;
}

.nav-link{
color:white !important;
}

.hero{
padding:50px 0;
}

.card{
border:none;
border-radius:18px;
transition:.3s;
}

.card:hover{
transform:translateY(-5px);
box-shadow:0 10px 25px rgba(0,0,0,.15);
}

.icon{
font-size:45px;
color:#D4AF37;
}

.btn-main{
background:#6F4E37;
color:white;
}

.btn-main:hover{
background:#5a3e2c;
color:white;
}

/* Best Seller Products */
.best-seller-section {
    margin-top: 40px;
    margin-bottom: 40px;
}

.best-seller-title {
    color: #6F4E37;
    font-weight: 700;
    margin-bottom: 25px;
}

.best-seller-card {
    border: none;
    border-radius: 15px;
    overflow: hidden;
    transition: 0.3s;
    height: 100%;
}

.best-seller-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.12);
}

.best-seller-card img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.best-seller-card .card-body {
    padding: 18px;
}

.best-seller-card h5 {
    color: #6F4E37;
    font-weight: 600;
}

.best-seller-price {
    color: #D4AF37;
    font-size: 20px;
    font-weight: 700;
}

.best-seller-badge {
    background: #6F4E37;
    color: white;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

</style>

</head>

<body>

<nav class="navbar navbar-expand-lg">

<div class="container">

<a class="navbar-brand" href="#">
🍰 Graham Delight
</a>

<div class="ms-auto">

<a href="../logout.php" class="btn btn-light">

Logout

</a>

</div>

</div>

</nav>

<div class="container hero">

<h2 class="mb-2">

Welcome,

<strong>

<?php echo htmlspecialchars($user); ?>

</strong>

👋

</h2>

<p class="text-muted mb-5">

What would you like to do today?

</p>

<div class="row g-4">

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-grid-fill"></i>

</div>

<h5 class="mt-3">

Browse Products

</h5>

<a href="products.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-cart-fill"></i>

</div>

<h5 class="mt-3">

My Cart

</h5>

<a href="cart.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-box-seam"></i>

</div>

<h5 class="mt-3">

My Orders

</h5>

<a href="my-orders.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-person-circle"></i>

</div>

<h5 class="mt-3">

Profile

</h5>

<a href="profile.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

</div>

<div class="best-seller-section">

    <h3 class="best-seller-title">
        <i class="bi bi-star-fill"></i> Best Seller Products
    </h3>

    <div class="row g-4">

        <?php if($bestSellerResult && $bestSellerResult->num_rows > 0){ ?>

            <?php while($product = $bestSellerResult->fetch_assoc()){ ?>

                <?php
                $image = "../uploads/products/" . $product['image'];

                if(empty($product['image']) || !file_exists($image)){
                    $image = "../assets/images/no-image.png";
                }
                ?>

                <div class="col-lg-3 col-md-6">

                    <div class="card best-seller-card shadow-sm">

                        <img 
                            src="<?php echo htmlspecialchars($image); ?>"
                            alt="<?php echo htmlspecialchars($product['product_name']); ?>"
                        >

                        <div class="card-body">

                            <span class="best-seller-badge">
                                <i class="bi bi-fire"></i>
                                Best Seller
                            </span>

                            <h5 class="mt-3">
                                <?php echo htmlspecialchars($product['product_name']); ?>
                            </h5>

                            <p class="best-seller-price mb-1">
                                ₱<?php echo number_format($product['price'], 2); ?>
                            </p>

                            <p class="text-muted mb-3">
                                <?php echo $product['total_sold']; ?> sold
                            </p>

                            <a href="products.php" class="btn btn-main w-100">
                                View Products
                            </a>

                        </div>

                    </div>

                </div>

            <?php } ?>

        <?php }else{ ?>

            <div class="col-12">

                <div class="alert alert-warning">
                    No best seller products available yet.
                </div>

            </div>

        <?php } ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>