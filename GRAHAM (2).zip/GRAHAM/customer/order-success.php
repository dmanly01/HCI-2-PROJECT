<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Order Success</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#FFF8F0;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
font-family:Poppins,sans-serif;
}

.card{
border:none;
border-radius:20px;
padding:40px;
text-align:center;
}

.success{
font-size:80px;
color:green;
}

</style>

</head>

<body>

<div class="card shadow">

<div class="success">

✅

</div>

<h2>

Order Placed Successfully!

</h2>

<p>

Thank you for ordering from Graham Delight.

</p>

<a
href="product.php"
class="btn btn-success">

Continue Shopping

</a>

<a
href="my-orders.php"
class="btn btn-primary">

My Orders

</a>

</div>

</body>

</html>