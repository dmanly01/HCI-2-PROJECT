<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD']!="POST"){
    header("Location: checkout.php");
    exit();
}

$payment_method = $_POST['payment_method'];
$total_amount = $_POST['total_amount'];

$conn->begin_transaction();

try{

$stmt = $conn->prepare("
INSERT INTO orders
(user_id,total_amount,payment_method,status)
VALUES(?,?,?,'Pending')
");

$stmt->bind_param(
"ids",
$user_id,
$total_amount,
$payment_method
);

$stmt->execute();

$order_id = $conn->insert_id;
$cart = $conn->prepare("
SELECT
c.product_id,
c.quantity,
p.price
FROM cart c
INNER JOIN products p
ON c.product_id=p.product_id
WHERE c.user_id=?
");

$cart->bind_param("i",$user_id);

$cart->execute();

$result = $cart->get_result();

while($row=$result->fetch_assoc()){

$product_id=$row['product_id'];

$qty=$row['quantity'];

$price=$row['price'];

$item=$conn->prepare("
INSERT INTO order_items
(order_id,product_id,quantity,price)
VALUES(?,?,?,?)
");

$item->bind_param(
"iiid",
$order_id,
$product_id,
$qty,
$price
);

$item->execute();

// Update inventory stock
$updateStock = $conn->prepare("
UPDATE inventory
SET stock = stock - ?
WHERE product_id = ?
");

$updateStock->bind_param(
"ii",
$qty,
$product_id
);

$updateStock->execute();

}

// Clear customer's cart
$deleteCart = $conn->prepare("
DELETE FROM cart
WHERE user_id=?
");

$deleteCart->bind_param("i",$user_id);
$deleteCart->execute();

// Commit transaction
$conn->commit();

// Redirect to success page
header("Location: order-success.php");
exit();

}catch(Exception $e){

$conn->rollback();

die("Order Failed : ".$e->getMessage());

}
?>