<?php
session_start();

include 'config/database.php';

$message = "";

/* Registration success message */
if (isset($_GET['registered']) && $_GET['registered'] == 1) {
    $message = "<div class='alert alert-success'>
                    Registration successful! You can now login.
                </div>";
}

/* LOGIN */
if (isset($_POST['login'])) {

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    /* =========================
       CHECK ADMIN
       ========================= */

    $stmt = $conn->prepare("
        SELECT admin_id, full_name, email, password
        FROM admins
        WHERE email = ?
        LIMIT 1
    ");

    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        $admin = $result->fetch_assoc();

        if (
            password_verify($password, $admin['password']) ||
            $password === $admin['password']
        ) {

            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['role'] = 'Admin';

            header("Location: admin/dashboard.php");
            exit();
        }
    }

    /* =========================
       CHECK CUSTOMER
       ========================= */

    $stmt = $conn->prepare("
        SELECT
            user_id,
            first_name,
            last_name,
            email,
            password,
            role,
            status
        FROM users
        WHERE email = ?
        LIMIT 1
    ");

    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        $user = $result->fetch_assoc();

        /* Check account status */

        if ($user['status'] !== 'Active') {

            $message = "<div class='alert alert-danger'>
                            Your account is inactive.
                        </div>";

        } elseif (
            password_verify($password, $user['password']) ||
            $password === $user['password']
        ) {

            $_SESSION['user_id'] = $user['user_id'];

            $_SESSION['user_name'] =
                $user['first_name'];

            $_SESSION['user_full_name'] =
                $user['first_name'] . " " .
                $user['last_name'];

            $_SESSION['user_email'] =
                $user['email'];

            $_SESSION['role'] = 'Customer';

            header("Location: customer/dashboard.php");
            exit();

        } else {

            $message = "<div class='alert alert-danger'>
                            Invalid email or password.
                        </div>";
        }

    } else {

        $message = "<div class='alert alert-danger'>
                        Invalid email or password.
                    </div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1">

<title>Login | Graham Delight</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

<style>

* {
    font-family: 'Poppins', sans-serif;
}

body {
    background: #FFF8F0;
    min-height: 100vh;

    display: flex;
    align-items: center;
    justify-content: center;
}

.login-card {
    width: 430px;
    border: none;
    border-radius: 20px;
    overflow: hidden;
}

.login-header {
    background: #6F4E37;
    color: white;
    text-align: center;
    padding: 30px;
}

.login-header h2 {
    font-weight: 700;
}

.login-header p {
    margin-bottom: 0;
}

.login-body {
    padding: 35px;
}

.form-control {
    padding: 12px;
    border-radius: 10px;
}

.btn-login {
    background: #D4AF37;
    color: white;
    font-weight: 600;
    border: none;
    padding: 12px;
}

.btn-login:hover {
    background: #b8922c;
    color: white;
}

</style>

</head>

<body>

<div class="card shadow-lg login-card">

    <div class="login-header">

        <h2>🍰 Graham Delight</h2>

        <p>Customer & Admin Login</p>

    </div>

    <div class="login-body">

        <?php echo $message; ?>

        <form method="POST">

            <div class="mb-3">

                <label class="form-label">
                    Email
                </label>

                <input
                    type="email"
                    name="email"
                    class="form-control"
                    placeholder="Enter your email"
                    required>

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    class="form-control"
                    placeholder="Enter your password"
                    required>

            </div>

            <button
                type="submit"
                name="login"
                class="btn btn-login w-100">

                Login

            </button>

        </form>

        <hr>

        <div class="text-center">

            Don't have an account?

            <a href="register.php">
                Register Here
            </a>

        </div>

    </div>

</div>

</body>

</html>