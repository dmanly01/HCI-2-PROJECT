<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$user = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Customer Dashboard | Graham Delight</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
font-family:'Poppins',sans-serif;
}

body{
background:#f8f5f2;
}

.navbar{
background:#6F4E37;
}

.navbar-brand{
color:white;
font-weight:bold;
font-size:24px;
}

.navbar-brand:hover{
color:white;
}

.nav-link{
color:white !important;
}

.hero{
padding:50px 0;
}

.card{
border:none;
border-radius:18px;
transition:.3s;
}

.card:hover{
transform:translateY(-5px);
box-shadow:0 10px 25px rgba(0,0,0,.15);
}

.icon{
font-size:45px;
color:#D4AF37;
}

.btn-main{
background:#6F4E37;
color:white;
}

.btn-main:hover{
background:#5a3e2c;
color:white;
}

</style>

</head>

<body>

<nav class="navbar navbar-expand-lg">

<div class="container">

<a class="navbar-brand" href="#">
🍰 Graham Delight
</a>

<div class="ms-auto">

<a href="../logout.php" class="btn btn-light">

Logout

</a>

</div>

</div>

</nav>

<div class="container hero">

<h2 class="mb-2">

Welcome,

<strong>

<?php echo htmlspecialchars($user); ?>

</strong>

👋

</h2>

<p class="text-muted mb-5">

What would you like to do today?

</p>

<div class="row g-4">

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-grid-fill"></i>

</div>

<h5 class="mt-3">

Browse Products

</h5>

<a href="products.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-cart-fill"></i>

</div>

<h5 class="mt-3">

My Cart

</h5>

<a href="cart.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-box-seam"></i>

</div>

<h5 class="mt-3">

My Orders

</h5>

<a href="my-orders.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow text-center p-4">

<div class="icon">

<i class="bi bi-person-circle"></i>

</div>

<h5 class="mt-3">

Profile

</h5>

<a href="profile.php" class="btn btn-main mt-3">

Open

</a>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>